"""Криптографический слой (шаг 4 и шаг 5).

Шаг 4 - защита чувствительных полей БД:
  * базовый алгоритм: Fernet (AES-128-CBC + HMAC-SHA256);
  * усиленный вариант: Кузнечик (ГОСТ Р 34.12-2015) в режиме CTR.
Значения в БД хранятся в виде:
  * fernet:<base64>  - зашифровано Fernet;
  * gost:<base64>    - зашифровано Кузнечиком.

Шаг 5 - подпись экспортируемых документов:
  * ECDSA (P-256) + SHA-256;
  * в подпись включаются метаданные (кем, когда, хеш содержимого).

Приватные ключи и секреты НЕ хранятся в репозитории (см. config.py и .env).
"""
from __future__ import annotations

import base64
import hashlib
import json
from typing import Any

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec

from . import config, gost

FERNET_PREFIX = "fernet:"


# =====================================================================
#  Шаг 4: шифрование чувствительных полей
# =====================================================================

_fernet_cache: Fernet | None = None


def _fernet() -> Fernet:
    global _fernet_cache
    if _fernet_cache is None:
        _fernet_cache = Fernet(config.fernet_key())
    return _fernet_cache


# Выбор алгоритма шифрования полей: 'fernet' (по умолчанию) или 'gost'.
_FIELD_ALGORITHM = "gost"  # усиленный вариант: отечественный Кузнечик


# Аудит-хук: устанавливается извне (audit.py), чтобы избежать
# циклической зависимости crypto <-> audit.
_audit_decrypt_hook = None


def set_audit_decrypt_hook(hook) -> None:
    """Регистрирует callback, вызываемый при каждой расшифровке поля."""
    global _audit_decrypt_hook
    _audit_decrypt_hook = hook


def encrypt_field(value: Any) -> Any:
    """Шифрует значение поля. None и уже зашифрованное возвращает как есть."""
    if value is None or value == "":
        return value
    text = str(value)
    if is_encrypted(text):
        return text
    if _FIELD_ALGORITHM == "gost":
        return gost.encrypt_str(text, config.gost_key())
    token = _fernet().encrypt(text.encode("utf-8"))
    return FERNET_PREFIX + token.decode("ascii")


def decrypt_field(value: Any, *, context: str = None) -> Any:
    """Расшифровывает значение. Логирует факт расшифровки (шаг 3)."""
    if value is None or value == "":
        return value
    if not is_encrypted(value):
        return value
    plaintext = _decrypt_raw(value)
    if _audit_decrypt_hook is not None:
        try:
            _audit_decrypt_hook(context or "field", "success")
        except Exception:
            pass
    return plaintext


def _decrypt_raw(value: str) -> str:
    if value.startswith(gost.GOST_PREFIX):
        return gost.decrypt_str(value, config.gost_key())
    if value.startswith(FERNET_PREFIX):
        token = value[len(FERNET_PREFIX):].encode("ascii")
        try:
            return _fernet().decrypt(token).decode("utf-8")
        except InvalidToken as exc:
            raise ValueError("Не удалось расшифровать поле (неверный ключ)") from exc
    raise ValueError("Неизвестный формат шифротекста")


def is_encrypted(value: Any) -> bool:
    return isinstance(value, str) and (
        value.startswith(FERNET_PREFIX) or value.startswith(gost.GOST_PREFIX)
    )


def decrypt_holder(holder: dict) -> dict:
    """Расшифровывает чувствительные поля владельца для выдачи в API."""
    if holder is None:
        return None
    result = dict(holder)
    if result.get("email"):
        result["email"] = decrypt_field(result["email"], context="holder.email")
    if result.get("phone"):
        result["phone"] = decrypt_field(result["phone"], context="holder.phone")
    return result


# =====================================================================
#  Шаг 5: подпись экспортируемых документов
# =====================================================================

_signing_key_cache = None
_verify_key_cache = None


def _private_key():
    global _signing_key_cache
    if _signing_key_cache is None:
        pem = config.signing_private_key_pem()
        _signing_key_cache = serialization.load_pem_private_key(pem, password=None)
    return _signing_key_cache


def _public_key():
    global _verify_key_cache
    if _verify_key_cache is None:
        _verify_key_cache = _private_key().public_key()
    return _verify_key_cache


def content_hash(content: bytes) -> str:
    """SHA-256 хеш содержимого документа (hex)."""
    return hashlib.sha256(content).hexdigest()


def public_key_pem() -> str:
    """Публичный ключ подписи в PEM - для независимой проверки."""
    return _public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("ascii")


def sign_document(content: bytes, meta: dict = None) -> dict:
    """Подписывает документ. Возвращает конверт с подписью и метаданными."""
    meta = dict(meta or {})
    meta["content_hash"] = content_hash(content)
    meta["algorithm"] = "ECDSA-P256-SHA256"
    payload = json.dumps(meta, ensure_ascii=False, sort_keys=True).encode("utf-8")
    signature = _private_key().sign(payload + content, ec.ECDSA(hashes.SHA256()))
    return {
        "meta": meta,
        "signature": base64.b64encode(signature).decode("ascii"),
        "public_key": public_key_pem(),
    }


def verify_document(content: bytes, envelope: dict) -> bool:
    """Проверяет подпись документа. True - подпись верна, False - изменён."""
    try:
        meta = envelope.get("meta") or {}
        expected_hash = meta.get("content_hash")
        if expected_hash != content_hash(content):
            return False
        payload = json.dumps(meta, ensure_ascii=False, sort_keys=True).encode("utf-8")
        signature = base64.b64decode(envelope["signature"])
        _public_key().verify(signature, payload + content, ec.ECDSA(hashes.SHA256()))
        return True
    except Exception:
        return False


# =====================================================================
#  Шаг 5. Подпись исходящих документов
#  Реэкспорт из crypto_signing для совместимости с api.py
# =====================================================================

from .crypto_signing import (  # noqa: E402,F401
    public_key_pem,
    sign_document,
    verify_document,
)


from .crypto_signing import (  # noqa: E402,F401
    sign_passes,
    verify_signature,
)
