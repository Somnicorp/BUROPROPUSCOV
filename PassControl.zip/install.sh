#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "============================================================"
echo "  Система учёта и проверки пропусков"
echo "  Установка и запуск (Linux/macOS)"
echo "============================================================"
echo

# --- 1. Python ---
if command -v python3 >/dev/null 2>&1; then
    PYTHON=python3
elif command -v python >/dev/null 2>&1; then
    PYTHON=python
else
    echo "[ОШИБКА] Python не найден. Установите Python 3.10+."
    exit 1
fi
echo "[*] $($PYTHON --version)"
echo

# --- 2. venv ---
if [ ! -f ".venv/bin/python" ]; then
    echo "[*] Создание виртуального окружения..."
    $PYTHON -m venv .venv
else
    echo "[*] Виртуальное окружение уже существует."
fi

VENV_PY=".venv/bin/python"

# --- 3. Зависимости ---
echo "[*] Установка зависимостей..."
$VENV_PY -m pip install --upgrade pip --quiet
$VENV_PY -m pip install -r backend/requirements.txt --quiet
echo "[*] Зависимости установлены."
echo

# --- 4. .env ---
if [ ! -f ".env" ]; then
    echo "[*] Генерация .env с секретами..."
    $VENV_PY scripts/generate_env.py
    echo "[*] .env создан."
else
    echo "[*] .env уже существует."
fi
echo

# --- 5. База данных ---
if [ ! -f "data/pass_control.sqlite3" ]; then
    echo "[*] Генерация базы данных..."
    $VENV_PY scripts/generate_data.py
else
    echo "[*] База данных уже существует."
fi

# --- 6. Ключи подписи ---
if [ ! -f "keys/signing_key.pem" ]; then
    echo "[*] Генерация ключей подписи..."
    $VENV_PY scripts/generate_keys.py
else
    echo "[*] Ключи подписи уже существуют."
fi
echo

# --- 7. Запуск сервера в фоне ---
echo "[*] Запуск сервера..."
nohup $VENV_PY backend/run.py > server.log 2>&1 &
SERVER_PID=$!
echo "$SERVER_PID" > .server.pid
echo "[*] Сервер запущен (PID $SERVER_PID). Лог: server.log"

# --- 8. Ожидание готовности ---
echo "[*] Ожидание запуска сервера..."
for i in $(seq 1 30); do
    if curl -sf http://127.0.0.1:8080/api/v1/health >/dev/null 2>&1; then
        echo "[*] Сервер готов."
        break
    fi
    sleep 1
done

# --- 9. Открытие браузера ---
URL="http://127.0.0.1:8080"
if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$URL" >/dev/null 2>&1 &
elif command -v open >/dev/null 2>&1; then
    open "$URL"
else
    echo "[*] Откройте вручную: $URL"
fi

echo
echo "============================================================"
echo "  ГОТОВО"
echo "============================================================"
echo "  Адрес:  $URL"
echo
echo "  Тестовые пользователи:"
echo "    admin    / Admin123!     (полный доступ)"
echo "    manager  / Manager123!   (управление данными)"
echo "    user     / User123!      (базовый доступ)"
echo "    guest    / Guest123!     (только просмотр)"
echo
echo "  Остановка сервера:  ./stop.sh"
echo "============================================================"