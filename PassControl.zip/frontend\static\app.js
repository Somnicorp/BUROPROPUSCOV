﻿/* ============================================================
   Система учёта и проверки пропусков — клиентское приложение
   ============================================================ */

// ---------- Утилиты ----------
function $(id) { return document.getElementById(id); }

function getCsrfToken() {
  const m = document.cookie.match(/(?:^|;\s*)csrf_token=([^;]+)/);
  return m ? decodeURIComponent(m[1]) : "";
}

async function apiFetch(path, options = {}) {
  const opts = {
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  };
  if (opts.method && opts.method !== "GET" && opts.method !== "HEAD") {
    opts.headers["X-CSRF-Token"] = getCsrfToken();
  }
  const res = await fetch(path, opts);
  if (res.status === 401) {
    showPage("page-login");
    setStatus($("login-status"), false, "Сессия истекла", "Войдите заново");
    throw new Error("unauthorized");
  }
  return res;
}

function setStatus(el, ok, title, details) {
  if (!el) return;
  el.classList.remove("hidden", "ok", "bad");
  el.classList.add(ok ? "ok" : "bad");
  el.innerHTML = `<span class="big">${ok ? "✓" : "✗"} ${escapeHtml(title)}</span>` +
    (details ? `<span class="muted">${escapeHtml(details)}</span>` : "");
}

function clearStatus(el) {
  if (el) el.classList.add("hidden");
}

function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

// ---------- Навигация ----------
const PAGES = [
  "page-login", "page-holders", "page-passes",
  "page-verify", "page-signing", "page-admin",
];

function showPage(pageId) {
  PAGES.forEach(p => {
    const el = $(p);
    if (el) el.classList.toggle("hidden", p !== pageId);
  });
  document.querySelectorAll(".nav-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.page === pageId);
  });
  // Автозагрузка данных при переходе
  if (pageId === "page-holders") loadHolders();
  if (pageId === "page-passes") loadPasses();
  if (pageId === "page-admin") { loadAdminUsers(); loadAdminLogs(); }
  if (pageId === "page-verify") loadAccessPoints();
}

document.addEventListener("click", (e) => {
  const btn = e.target.closest(".nav-btn");
  if (btn && btn.dataset.page) showPage(btn.dataset.page);
});

// ---------- Аутентификация (вариант 7 — рукопожатие) ----------
async function sha256Hex(text) {
  const enc = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest("SHA-256", enc);
  return Array.from(new Uint8Array(buf))
    .map(b => b.toString(16).padStart(2, "0"))
    .join("");
}

async function hmacSha256Hex(keyHex, message) {
  const keyBytes = new Uint8Array(keyHex.match(/.{2}/g).map(b => parseInt(b, 16)));
  const key = await crypto.subtle.importKey(
    "raw", keyBytes, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message));
  return Array.from(new Uint8Array(sig))
    .map(b => b.toString(16).padStart(2, "0"))
    .join("");
}

async function doLogin() {
  const username = $("login-username").value.trim();
  const password = $("login-password").value;
  const status = $("login-status");
  if (!username || !password) {
    setStatus(status, false, "Заполните логин и пароль");
    return;
  }

  try {
    // 1. Challenge
    const challengeRes = await fetch("/api/auth/challenge", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ username }),
    });
    if (!challengeRes.ok) {
      setStatus(status, false, "Ошибка входа", "Неверный логин или пароль");
      return;
    }
    const challengeData = await challengeRes.json();
    const challenge = challengeData.challenge;

    // 2. Response = HMAC-SHA256(challenge, key=SHA256(password))
    const keyHex = await sha256Hex(password);
    const response = await hmacSha256Hex(keyHex, challenge);

    // 3. Отправка ответа
    const responseRes = await fetch("/api/auth/response", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ username, response }),
    });
    if (!responseRes.ok) {
      const err = await responseRes.json().catch(() => ({}));
      setStatus(status, false, "Ошибка входа", err.error || "Неверный пароль");
      return;
    }
    const data = await responseRes.json();
    setStatus(status, true, "Вход выполнен", `Пользователь: ${data.user?.username}, роль: ${data.user?.role}`);
    $("current-user").textContent = `${data.user?.username} (${data.user?.role})`;
    setTimeout(() => showPage("page-holders"), 800);
  } catch (e) {
    setStatus(status, false, "Сеть", String(e));
  }
}

async function doRegister() {
  const username = $("reg-username").value.trim();
  const password = $("reg-password").value;
  const status = $("reg-status");
  if (!username || !password) {
    setStatus(status, false, "Заполните логин и пароль");
    return;
  }
  try {
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setStatus(status, false, "Ошибка регистрации", data.error || "Попробуйте другой логин");
      return;
    }
    setStatus(status, true, "Регистрация успешна", "Теперь можно войти");
    $("login-username").value = username;
    $("login-password").value = password;
  } catch (e) {
    setStatus(status, false, "Сеть", String(e));
  }
}

async function doLogout() {
  try {
    await apiFetch("/api/auth/logout", { method: "POST" });
  } catch (e) { /* ignore */ }
  $("current-user").textContent = "не авторизован";
  showPage("page-login");
}

// ---------- Владельцы ----------
async function loadHolders() {
  const search = $("holders-search").value.trim();
  const url = "/api/v1/holders" + (search ? `?search=${encodeURIComponent(search)}` : "");
  try {
    const res = await apiFetch(url);
    if (!res.ok) return;
    const items = await res.json();
    const tbody = $("holders-table").querySelector("tbody");
    tbody.innerHTML = "";
    (items || []).slice(0, 200).forEach(h => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${h.id}</td>
        <td>${escapeHtml(h.full_name || "")}</td>
        <td>${escapeHtml(h.company || "")}</td>
        <td>${escapeHtml(h.position || "")}</td>
        <td>${escapeHtml(h.email || "***")}</td>
        <td>${escapeHtml(h.phone || "***")}</td>
      `;
      tbody.appendChild(tr);
    });
  } catch (e) { /* ignore */ }
}

// ---------- Пропуска ----------
async function loadPasses() {
  const status = $("passes-status").value;
  const url = "/api/v1/passes" + (status ? `?status=${status}` : "");
  try {
    const res = await apiFetch(url);
    if (!res.ok) return;
    const items = await res.json();
    const tbody = $("passes-table").querySelector("tbody");
    tbody.innerHTML = "";
    (items || []).slice(0, 200).forEach(p => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${p.id}</td>
        <td><code>${escapeHtml(p.card_number || "")}</code></td>
        <td>${p.holder_id}</td>
        <td><span class="tag ${p.status}">${p.status}</span></td>
        <td>${escapeHtml((p.valid_until || p.valid_to || "").slice(0, 10))}</td>
      `;
      tbody.appendChild(tr);
    });
  } catch (e) { /* ignore */ }
}

// ---------- Проверка на КПП ----------
async function loadAccessPoints() {
  try {
    const res = await apiFetch("/api/v1/access-points");
    if (!res.ok) return;
    const items = await res.json();
    const sel = $("verify-point");
    sel.innerHTML = "";
    (items || []).forEach(ap => {
      const opt = document.createElement("option");
      opt.value = ap.id;
      opt.textContent = ap.name;
      sel.appendChild(opt);
    });
  } catch (e) { /* ignore */ }
}

async function doVerify() {
  const card = $("verify-card").value.trim();
  const pointId = parseInt($("verify-point").value, 10);
  const result = $("verify-result");
  if (!card || !pointId) {
    setStatus(result, false, "Заполните номер карты");
    return;
  }
  try {
    const res = await apiFetch("/api/v1/passes/verify", {
      method: "POST",
      body: JSON.stringify({ card_number: card, access_point_id: pointId }),
    });
    const data = await res.json();
    if (data.result === "granted") {
      setStatus(result, true, "ПРОХОД РАЗРЕШЁН", `Карта: ${card}, точка: ${pointId}`);
    } else {
      setStatus(result, false, "ПРОХОД ЗАПРЕЩЁН", data.reason || "пропуск недействителен");
    }
  } catch (e) {
    setStatus(result, false, "Сеть", String(e));
  }
}

// ---------- Шаг 5. Экспорт и подпись ----------
let lastEnvelope = null;

async function exportSigned() {
  const status = $("signing-status");
  const pre = $("signing-envelope");
  try {
    const res = await apiFetch("/api/v1/export/passes");
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      setStatus(status, false, "Ошибка экспорта", err.error || res.statusText);
      return;
    }
    const envelope = await res.json();
    lastEnvelope = envelope;
    pre.textContent = JSON.stringify(envelope, null, 2);
    setStatus(status, true, "Документ подписан",
      `Алгоритм: ${envelope.algorithm}; подписал: ${envelope.metadata.signed_by}; ` +
      `время: ${envelope.metadata.signed_at}; ` +
      `хеш: ${envelope.metadata.content_sha256.slice(0, 16)}...`);
  } catch (e) {
    setStatus(status, false, "Сеть", String(e));
  }
}

async function verifySignature() {
  const status = $("signing-verify-status");
  const input = $("signing-verify-input");
  let envelope;
  try {
    envelope = JSON.parse(input.value);
  } catch (e) {
    setStatus(status, false, "Ошибка JSON", String(e));
    return;
  }
  try {
    const res = await apiFetch("/api/v1/verify/signature", {
      method: "POST",
      body: JSON.stringify(envelope),
    });
    const data = await res.json();
    if (data.valid) {
      setStatus(status, true, "Подпись верна",
        `Подписал: ${data.metadata?.signed_by}; время: ${data.metadata?.signed_at}`);
    } else {
      setStatus(status, false, "Подпись НЕВЕРНА",
        data.reason || "документ изменён или подпись подделана");
    }
  } catch (e) {
    setStatus(status, false, "Сеть", String(e));
  }
}

async function showPublicKey() {
  try {
    const res = await fetch("/api/v1/signing/public-key");
    const data = await res.json();
    $("signing-pubkey").textContent = data.public_key_pem || "—";
  } catch (e) {
    $("signing-pubkey").textContent = "Ошибка: " + e;
  }
}

function pasteCurrentEnvelope() {
  if (lastEnvelope) {
    $("signing-verify-input").value = JSON.stringify(lastEnvelope, null, 2);
  } else {
    setStatus($("signing-verify-status"), false, "Сначала сделайте экспорт");
  }
}

function tamperEnvelope() {
  const input = $("signing-verify-input");
  let envelope;
  try {
    envelope = JSON.parse(input.value);
  } catch (e) {
    setStatus($("signing-verify-status"), false, "Ошибка JSON", String(e));
    return;
  }
  if (Array.isArray(envelope.document) && envelope.document.length > 0) {
    envelope.document[0].card_number = "HACKED-CARD-000";
    input.value = JSON.stringify(envelope, null, 2);
    setStatus($("signing-verify-status"), false, "Документ подделан",
      "Поле card_number изменено. Теперь проверьте подпись.");
  }
}

// ---------- Админ ----------
async function loadAdminUsers() {
  try {
    const res = await apiFetch("/api/v1/admin/users");
    if (!res.ok) return;
    const items = await res.json();
    const tbody = $("admin-users-table").querySelector("tbody");
    tbody.innerHTML = "";
    (items || []).forEach(u => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${u.id}</td>
        <td>${escapeHtml(u.username)}</td>
        <td><span class="tag ${u.role}">${u.role}</span></td>
        <td>${u.is_active ? "да" : "нет"}</td>
      `;
      tbody.appendChild(tr);
    });
  } catch (e) { /* ignore */ }
}

async function loadAdminLogs() {
  try {
    const res = await apiFetch("/api/v1/admin/logs");
    if (!res.ok) return;
    const data = await res.json();
    const logs = data.logs || data;
    const tbody = $("admin-logs-table").querySelector("tbody");
    tbody.innerHTML = "";
    (logs || []).slice(0, 200).forEach(l => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${l.id}</td>
        <td>${escapeHtml((l.timestamp || "").slice(0, 19))}</td>
        <td>${escapeHtml(l.user || "—")}</td>
        <td>${escapeHtml(l.action || "")}</td>
        <td><span class="tag ${l.outcome === 'success' ? 'granted' : 'denied'}">${escapeHtml(l.outcome || "")}</span></td>
      `;
      tbody.appendChild(tr);
    });
  } catch (e) { /* ignore */ }
}

// ---------- Инициализация ----------
document.addEventListener("DOMContentLoaded", () => {
  // Кнопки входа
  $("btn-login")?.addEventListener("click", doLogin);
  $("btn-register")?.addEventListener("click", doRegister);
  $("btn-logout")?.addEventListener("click", doLogout);

  // Владельцы
  $("btn-holders-load")?.addEventListener("click", loadHolders);
  $("btn-holders-create")?.addEventListener("click", () => alert("Создание владельца — через API /api/v1/holders"));

  // Пропуска
  $("btn-passes-load")?.addEventListener("click", loadPasses);

  // Проверка
  $("btn-verify")?.addEventListener("click", doVerify);

  // Подпись
  $("btn-export-signed")?.addEventListener("click", exportSigned);
  $("btn-verify-signature")?.addEventListener("click", verifySignature);
  $("btn-show-pubkey")?.addEventListener("click", showPublicKey);
  $("btn-paste-current")?.addEventListener("click", pasteCurrentEnvelope);
  $("btn-tamper")?.addEventListener("click", tamperEnvelope);

  // Админ
  $("btn-admin-users")?.addEventListener("click", loadAdminUsers);
  $("btn-admin-logs")?.addEventListener("click", loadAdminLogs);

  showPage("page-login");
});
