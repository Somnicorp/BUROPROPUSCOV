"""Сборка установочного архива системы учёта и проверки пропусков.

Создаёт:
  * dist/PassControl-setup.zip   — архив с проектом и установщиком;
  * dist/Установить.bat          — самораспаковывающийся установщик (Windows);
  * dist/установить.sh           — самораспаковывающийся установщик (Linux/macOS).

Запуск:  python build_release.py
"""
from __future__ import annotations

import os
import zipfile

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DIST_DIR = os.path.join(BASE_DIR, "dist")
ARCHIVE = os.path.join(DIST_DIR, "PassControl-setup.zip")

INCLUDE_FILES = [
    "run.py",
    "generate_data.py",
    "installer.py",
    "requirements.txt",
    "start.bat",
    "start.sh",
    "README.md",
    "app/__init__.py",
    "app/api.py",
    "app/api_deps.py",
    "app/auth.py",
    "app/audit.py",
    "app/config.py",
    "app/crypto.py",
    "app/database.py",
    "app/gost.py",
    "app/main.py",
    "app/middleware.py",
    "app/repository.py",
    "app/security.py",
    "app/services.py",
    "app/users.py",
    "app/templates/index.html",
    "app/static/app.js",
    "app/static/style.css",
]

BAT_INSTALLER = "@echo off\n" \
    "chcp 65001 >nul\n" \
    "title Установка: Система учёта и проверки пропусков\n" \
    "cd /d \"%~dp0\"\n\n" \
    "echo ============================================================\n" \
    "echo   Установка: Система учёта и проверки пропусков\n" \
    "echo ============================================================\n" \
    "echo.\n" \
    "echo [1/3] Распаковка архива ...\n" \
    "powershell -NoProfile -Command \"Expand-Archive -Path 'PassControl-setup.zip' -DestinationPath '.' -Force\"\n" \
    "if errorlevel 1 (\n" \
    "    echo [ОШИБКА] Не удалось распаковать архив.\n" \
    "    pause\n" \
    "    exit /b 1\n" \
    ")\n\n" \
    "echo [2/3] Запуск установщика Python ...\n" \
    "python installer.py --source .\n" \
    "if errorlevel 1 (\n" \
    "    echo [ОШИБКА] Установка не удалась. Убедитесь, что установлен Python 3.10+.\n" \
    "    pause\n" \
    "    exit /b 1\n" \
    ")\n\n" \
    "echo [3/3] Готово!\n" \
    "echo.\n" \
    "echo Приложение установлено. Запуск: %%USERPROFILE%%\\FlaskPassControl\\Запустить.bat\n" \
    "echo.\n" \
    "pause\n"

SH_INSTALLER = "#!/usr/bin/env bash\n" \
    "set -e\n" \
    "cd \"$(dirname \"$0\")\"\n\n" \
    "echo '============================================================'\n" \
    "echo '  Установка: Система учёта и проверки пропусков'\n" \
    "echo '============================================================'\n\n" \
    "echo '[1/3] Распаковка архива...'\n" \
    "if command -v unzip >/dev/null 2>&1; then\n" \
    "    unzip -o PassControl-setup.zip -d .\n" \
    "else\n" \
    "    python3 -c \"import zipfile; zipfile.ZipFile('PassControl-setup.zip').extractall('.')\"\n" \
    "fi\n\n" \
    "echo '[2/3] Запуск установщика...'\n" \
    "python3 installer.py --source .\n\n" \
    "echo '[3/3] Готово!'\n" \
    "echo 'Приложение установлено в ~/FlaskPassControl'\n"


def build_archive() -> str:
    os.makedirs(DIST_DIR, exist_ok=True)
    if os.path.exists(ARCHIVE):
        os.remove(ARCHIVE)
    with zipfile.ZipFile(ARCHIVE, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel in INCLUDE_FILES:
            path = os.path.join(BASE_DIR, rel)
            if os.path.exists(path):
                zf.write(path, rel)
                print(f"  + {rel}")
            else:
                print(f"  [пропуск] {rel}")
    return ARCHIVE


def write_installers() -> None:
    bat = os.path.join(DIST_DIR, "Установить.bat")
    with open(bat, "w", encoding="utf-8") as fh:
        fh.write(BAT_INSTALLER)
    sh = os.path.join(DIST_DIR, "установить.sh")
    with open(sh, "w", encoding="utf-8") as fh:
        fh.write(SH_INSTALLER)
    try:
        os.chmod(sh, 0o755)
    except OSError:
        pass
    print(f"  + {bat}")
    print(f"  + {sh}")


def main() -> None:
    print("Сборка установочного архива...")
    archive = build_archive()
    print("Создание установщиков...")
    write_installers()
    size = os.path.getsize(archive) / 1024
    print(f"\nГотово! Архив: {archive} ({size:.1f} КБ)")


if __name__ == "__main__":
    main()
