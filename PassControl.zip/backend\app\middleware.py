"""Middleware безопасности: HTTP-заголовки, CSP, обработка 401 (шаг 6).

Безопасные заголовки:
  * Content-Security-Policy (CSP) - запрет inline-скриптов, ограничение источников;
  * Strict-Transport-Security (HSTS);
  * X-Content-Type-Options: nosniff;
  * X-Frame-Options: DENY (дублируется CSP frame-ancestors 'none');
  * Referrer-Policy: no-referrer.
"""
from __future__ import annotations

from flask import jsonify, request


# CSP: только собственные скрипты/стили, без inline.
# Примечание: frontend вынесен в отдельные файлы, inline-скриптов нет.
CSP_POLICY = (
    "default-src 'self'; "
    "script-src 'self'; "
    "style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data:; "
    "connect-src 'self'; "
    "font-src 'self'; "
    "object-src 'none'; "
    "base-uri 'self'; "
    "form-action 'self'; "
    "frame-ancestors 'none'"
)

SECURITY_HEADERS = {
    "Content-Security-Policy": CSP_POLICY,
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": "geolocation=(), microphone=(), camera=()",
    "Cross-Origin-Opener-Policy": "same-origin",
}


def register_middleware(app) -> None:
    """Регистрирует заголовки безопасности и обработчики ошибок."""

    @app.after_request
    def add_security_headers(response):
        for header, value in SECURITY_HEADERS.items():
            response.headers.setdefault(header, value)
        # HSTS - только если соединение защищено (иначе бессмысленно/вредно).
        if request.is_secure:
            response.headers.setdefault(
                "Strict-Transport-Security",
                "max-age=31536000; includeSubDomains",
            )
        return response

    @app.errorhandler(401)
    def handle_401(_):
        # API -> JSON 401, чтобы фронтенд сделал редирект на форму входа.
        if request.path.startswith("/api"):
            return jsonify({"error": "Требуется аутентификация"}), 401
        return jsonify({"error": "Требуется аутентификация"}), 401
