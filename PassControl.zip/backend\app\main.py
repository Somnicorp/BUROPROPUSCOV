﻿"""Точка входа Flask-приложения «Система учёта и проверки пропусков»."""
from __future__ import annotations

import os
from pathlib import Path

from flask import Flask, jsonify, render_template, request

from . import __version__
from . import middleware as middleware_module


PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
FRONTEND_DIR = PROJECT_ROOT / "frontend"


def _get_blueprint(module, *names):
    """Возвращает первый найденный blueprint из модуля."""
    for name in names:
        bp = getattr(module, name, None)
        if bp is not None and hasattr(bp, "register"):
            return bp
    return None


def _install_middleware(app: Flask) -> None:
    """Устанавливает middleware, если в модуле есть подходящая функция."""
    for name in ("install_middleware", "init_middleware",
                 "register_middleware", "setup_middleware",
                 "init_app", "setup"):
        fn = getattr(middleware_module, name, None)
        if callable(fn):
            try:
                fn(app)
                return
            except TypeError:
                continue
    # Если функций нет — возможно, middleware регистрируется
    # декораторами @app.after_request при импорте модуля.


def create_app() -> Flask:
    app = Flask(
        __name__,
        template_folder=str(FRONTEND_DIR / "templates"),
        static_folder=str(FRONTEND_DIR / "static"),
        static_url_path="/static",
    )
    app.config["SECRET_KEY"] = os.environ.get("JWT_SECRET", "dev-secret")

    # --- Blueprints ---
    from . import api as api_module
    from . import auth as auth_module

    api_bp = _get_blueprint(api_module, "api", "api_bp", "bp")
    auth_bp = _get_blueprint(auth_module, "auth_bp", "auth", "bp")

    if api_bp is not None:
        app.register_blueprint(api_bp, url_prefix="/api/v1")
    if auth_bp is not None:
        # auth может быть зарегистрирован с префиксом /api/auth
        # или уже содержать /api/auth внутри — пробуем без префикса,
        # если не сработает, поправим.
        app.register_blueprint(auth_bp, url_prefix="/api")

    _install_middleware(app)

    @app.get("/")
    def index():
        return render_template("index.html", version=__version__)

    @app.get("/api/v1/health")
    def health():
        return jsonify({
            "app": "Pass Control API",
            "status": "ok",
            "version": __version__,
        })

    @app.errorhandler(404)
    def not_found(err):
        if request.path.startswith("/api/"):
            return jsonify({"error": "not_found"}), 404
        return render_template("index.html", version=__version__), 404

    @app.errorhandler(500)
    def server_error(err):
        return jsonify({"error": "internal_error"}), 500

    return app


app = create_app()

