"""Операции над пользователями и роли RBAC (шаги 1-2).

Роли (единые для всех вариантов):
  * admin   - полный доступ;
  * manager - управление данными;
  * user    - базовый доступ;
  * guest   - только просмотр.

Проверка прав выполняется СТРОГО на сервере (см. app/auth.py),
скрытие элементов UI - лишь удобство, не защита.
"""
from __future__ import annotations

from . import database, security

ROLES = ("admin", "manager", "user", "guest")

# Иерархия ролей: чем больше число, тем больше прав.
ROLE_LEVEL = {"guest": 0, "user": 1, "manager": 2, "admin": 3}

USER_FIELDS = (
    "id", "username", "role", "is_active",
    "password_changed_at", "created_at", "last_login_at",
)


def _row_to_dict(row) -> dict | None:
    return {f: row[f] for f in USER_FIELDS} if row is not None else None


def get_by_id(user_id: int) -> dict | None:
    with database.cursor() as cur:
        cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        return _row_to_dict(cur.fetchone())


def get_by_username(username: str) -> dict | None:
    with database.cursor() as cur:
        cur.execute("SELECT * FROM users WHERE username = ?", (username,))
        return _row_to_dict(cur.fetchone())


def get_raw_by_username(username: str) -> dict | None:
    """Возвращает запись со всеми полями, включая password_hash (для auth)."""
    with database.cursor() as cur:
        cur.execute("SELECT * FROM users WHERE username = ?", (username,))
        row = cur.fetchone()
        return dict(row) if row else None


def list_users() -> list:
    with database.cursor() as cur:
        cur.execute("SELECT * FROM users ORDER BY id")
        return [_row_to_dict(r) for r in cur.fetchall()]


def _challenge_key(password: str) -> str:
    """Детерминированный ключ «рукопожатия» из пароля.

    Ключ = SHA-256(password). SHA-256 выбран потому, что он доступен
    и на сервере, и в браузере через Web Crypto API - это позволяет
    клиенту вычислить ответ без передачи пароля по сети и без
    сторонних JS-библиотек. Отечественные алгоритмы (Кузнечик/Стрибог)
    применяются для шифрования полей (шаг 4) и целостности журнала (шаг 3).
    """
    import hashlib
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def create_user(username: str, password: str, role: str = "user") -> dict:
    if role not in ROLES:
        raise ValueError(f"Недопустимая роль: {role}")
    now = database.utcnow()
    with database.cursor() as cur:
        cur.execute(
            "INSERT INTO users (username, password_hash, challenge_key, role, "
            "is_active, password_changed_at, created_at) "
            "VALUES (?, ?, ?, ?, 1, ?, ?)",
            (username, security.hash_password(password), _challenge_key(password), role, now, now),
        )
        new_id = cur.lastrowid
    return get_by_id(new_id)


def update_role(user_id: int, role: str) -> dict | None:
    if role not in ROLES:
        raise ValueError(f"Недопустимая роль: {role}")
    with database.cursor() as cur:
        cur.execute("UPDATE users SET role = ? WHERE id = ?", (role, user_id))
    return get_by_id(user_id)


def set_password(user_id: int, password: str) -> None:
    with database.cursor() as cur:
        cur.execute(
            "UPDATE users SET password_hash = ?, challenge_key = ?, "
            "password_changed_at = ? WHERE id = ?",
            (security.hash_password(password), _challenge_key(password),
             database.utcnow(), user_id),
        )


def set_challenge(user_id: int, challenge: str, ttl_seconds: int = 120) -> None:
    from datetime import datetime, timedelta, timezone
    until = (datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)).isoformat()
    with database.cursor() as cur:
        cur.execute(
            "UPDATE users SET challenge = ?, challenge_until = ? WHERE id = ?",
            (challenge, until, user_id),
        )


def clear_challenge(user_id: int) -> None:
    with database.cursor() as cur:
        cur.execute(
            "UPDATE users SET challenge = NULL, challenge_until = NULL WHERE id = ?",
            (user_id,),
        )


def mark_login(user_id: int) -> None:
    with database.cursor() as cur:
        cur.execute(
            "UPDATE users SET last_login_at = ? WHERE id = ?",
            (database.utcnow(), user_id),
        )


def delete_user(user_id: int) -> bool:
    with database.cursor() as cur:
        cur.execute("DELETE FROM users WHERE id = ?", (user_id,))
        return cur.rowcount > 0


def ensure_admin(username: str, password: str) -> dict:
    """Создаёт администратора, если он ещё не существует."""
    existing = get_by_username(username)
    if existing:
        return existing
    return create_user(username, password, role="admin")
