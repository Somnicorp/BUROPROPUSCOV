﻿"""Сброс паролей всех пользователей на 123456789.

Использование:
    python scripts/reset_passwords.py
    python scripts/reset_passwords.py --password "другой-пароль"

Обновляет password_hash (bcrypt) и challenge_key (SHA-256 от пароля).
Полезно для учебной демонстрации, когда пароли забыты.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


from backend.app import config, database, security, users  # noqa: E402


DEFAULT_PASSWORD = "123456789"

DEFAULT_USERS = [
    ("admin", "admin"),
    ("manager", "manager"),
    ("user", "user"),
    ("guest", "guest"),
]


def _challenge_key(password: str) -> str:
    """Тот же алгоритм, что в users._challenge_key.

    Пытаемся импортировать из users, если функция публичная.
    Иначе — вычисляем локально.
    """
    try:
        from backend.app.users import _challenge_key as impl  # type: ignore
        return impl(password)
    except Exception:
        import hashlib
        return hashlib.sha256(password.encode("utf-8")).hexdigest()


def reset_password_for(username: str, new_password: str) -> bool:
    """Меняет пароль пользователю. Возвращает True, если пользователь найден."""
    user = users.get_by_username(username)
    if not user:
        return False

    user_id = user["id"]
    new_hash = security.hash_password(new_password)
    new_challenge_key = _challenge_key(new_password)
    now = database.utcnow()

    with database.cursor() as cur:
        cur.execute(
            "UPDATE users SET password_hash = ?, challenge_key = ?, "
            "password_changed_at = ? WHERE id = ?",
            (new_hash, new_challenge_key, now, user_id),
        )
    return True


def ensure_user(username: str, password: str, role: str) -> None:
    """Создаёт пользователя, если его нет. Иначе — сбрасывает пароль."""
    existing = users.get_by_username(username)
    if existing:
        reset_password_for(username, password)
        print(f"  {username:10s} / {password}   (пароль сброшен, роль {existing.get('role')})")
    else:
        try:
            users.create_user(username, password, role=role)
            print(f"  {username:10s} / {password}   (создан, роль {role})")
        except Exception as exc:
            print(f"  {username:10s} — ошибка: {exc}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Сброс паролей")
    parser.add_argument("--password", default=DEFAULT_PASSWORD,
                        help=f"новый пароль (по умолчанию {DEFAULT_PASSWORD})")
    args = parser.parse_args()

    new_password = args.password

    print(f"БД: {config.DB_PATH}")
    database.init_db()

    print()
    print(f"Установка пароля '{new_password}' для пользователей:")
    for username, role in DEFAULT_USERS:
        ensure_user(username, new_password, role)

    print()
    print("[OK] Готово. Все пароли =", new_password)
    return 0


if __name__ == "__main__":
    sys.exit(main())
