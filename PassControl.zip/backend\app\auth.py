"""Аутентификация (шаг 1, вариант 7 «рукопожатие»), RBAC (шаг 2) и
управление сессиями (шаг 6).

Метод варианта - challenge-response («рукопожатие»):
  1) POST /api/auth/challenge  {username} -> {challenge}
  2) POST /api/auth/response   {username, response} -> {token}
Ответ вычисляется как HMAC-SHA256(challenge, производный от пароля ключ),
поэтому сам пароль по сети не передаётся.

Проверка прав выполняется на сервере через декоратор require_role.
"""
from __future__ import annotations

import functools
import hashlib
import hmac
import secrets

from flask import Blueprint, g, jsonify, make_response, request

from . import audit, config, security, users
from .users import ROLE_LEVEL

auth_bp = Blueprint("auth", __name__, url_prefix="/api")


# =====================================================================
#  Вспомогательные: клиент, cookie, CSRF
# =====================================================================


def client_ip() -> str:
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.remote_addr or "unknown"


def _set_auth_cookies(response, access_token: str, refresh_token: str, session_id: str):
    secure = not config.ALLOW_INSECURE
    response.set_cookie(
        "access_token", access_token,
        httponly=True, samesite="Lax", secure=secure,
        max_age=config.ACCESS_TOKEN_TTL, path="/",
    )
    response.set_cookie(
        "refresh_token", refresh_token,
        httponly=True, samesite="Lax", secure=secure,
        max_age=config.REFRESH_TOKEN_TTL, path="/",
    )
    response.set_cookie(
        "session_id", session_id,
        httponly=True, samesite="Lax", secure=secure,
        max_age=config.REFRESH_TOKEN_TTL, path="/",
    )
    # CSRF double-submit cookie (читается JS, дублируется в заголовке).
    csrf = security.generate_csrf_token()
    response.set_cookie(
        security.CSRF_COOKIE, csrf,
        httponly=False, samesite="Lax", secure=secure, path="/",
    )
    return response


def _clear_auth_cookies(response):
    for name in ("access_token", "refresh_token", "session_id", security.CSRF_COOKIE):
        response.delete_cookie(name, path="/")
    return response


# =====================================================================
#  Извлечение текущего пользователя
# =====================================================================


def _token_from_request() -> str | None:
    token = request.cookies.get("access_token")
    if token:
        return token
    header = request.headers.get("Authorization", "")
    if header.startswith("Bearer "):
        return header[7:]
    return None


def load_current_user() -> dict | None:
    """Загружает пользователя из access-token и проверяет активность сессии."""
    token = _token_from_request()
    if not token:
        return None
    payload = security.decode_access_token(token)
    if not payload:
        return None
    session_id = payload.get("sid")
    if not session_id or not security.is_session_active(session_id):
        return None
    user = users.get_by_id(int(payload["sub"]))
    if not user or not user.get("is_active"):
        return None
    g.current_user = user
    g.session_id = session_id
    audit.set_decrypt_context(
        username=user["username"], user_id=user["id"], ip=client_ip()
    )
    return user


# =====================================================================
#  Декораторы доступа (RBAC, шаг 2)
# =====================================================================


def _deny(reason: str, user: dict = None, status: int = 403):
    audit.log_event(
        audit.ACTION_ACCESS_DENIED,
        outcome="failure",
        username=(user or {}).get("username"),
        user_id=(user or {}).get("id"),
        details=reason,
        ip_address=client_ip(),
    )
    return jsonify({"error": "Доступ запрещён", "reason": reason}), status


def require_auth(fn):
    """Требует валидный access-token. Иначе 401 (редирект на форму входа)."""
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        user = load_current_user()
        if not user:
            return jsonify({"error": "Требуется аутентификация"}), 401
        return fn(*args, **kwargs)
    return wrapper


def require_role(min_role: str):
    """Требует роль не ниже min_role. Проверка строго на сервере."""
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            user = load_current_user()
            if not user:
                return jsonify({"error": "Требуется аутентификация"}), 401
            if ROLE_LEVEL.get(user["role"], -1) < ROLE_LEVEL.get(min_role, 99):
                return _deny(f"role<{min_role}", user)
            return fn(*args, **kwargs)
        return wrapper
    return decorator


# Эндпоинты, которые выполняются до появления сессии и поэтому не могут
# нести CSRF-токен: они защищены rate limit (шаг 6) и не действуют от имени
# уже аутентифицированного пользователя. CSRF для них неприменим по смыслу.
_CSRF_EXEMPT_PATHS = frozenset({
    "/api/auth/register",
    "/api/auth/challenge",
    "/api/auth/response",
})


def csrf_protect(fn):
    """Проверяет CSRF-токен для изменяющих запросов (шаг 6).

    Реализована схема double-submit cookie: значение cookie csrf_token
    должно совпасть со значением заголовка X-CSRF-Token. Cookie читаема
    из JS (httponly=False), но сторонний сайт не может ни прочитать её
    (Same-Origin Policy), ни выставить заголовок к чужому запросу.
    """
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            if request.path not in _CSRF_EXEMPT_PATHS:
                cookie = request.cookies.get(security.CSRF_COOKIE)
                header = request.headers.get(security.CSRF_HEADER)
                if not security.csrf_valid(cookie, header):
                    audit.log_event(
                        audit.ACTION_CSRF_REJECT, outcome="failure",
                        details=f"{request.method} {request.path}",
                        ip_address=client_ip(),
                    )
                    return jsonify({"error": "Недействительный CSRF-токен"}), 403
        return fn(*args, **kwargs)
    return wrapper


# =====================================================================
#  Challenge-response («рукопожатие», вариант 7)
# =====================================================================


def _derive_response(password: str, challenge: str) -> str:
    """HMAC-SHA256(challenge, key=SHA-256(password))."""
    key = hashlib.sha256(password.encode("utf-8")).digest()
    return hmac.new(key, challenge.encode("utf-8"), hashlib.sha256).hexdigest()


def _derive_response_from_key(challenge_key_hex: str, challenge: str) -> str:
    """Ожидаемый ответ по сохранённому HMAC-ключу (challenge_key)."""
    key = bytes.fromhex(challenge_key_hex)
    return hmac.new(key, challenge.encode("utf-8"), hashlib.sha256).hexdigest()


# =====================================================================
#  Эндпоинты аутентификации
# =====================================================================


def _issue_tokens(user: dict):
    session = security.create_session(user["id"], request.headers.get("User-Agent"), client_ip())
    access = security.create_access_token(user, session["session_id"])
    return access, session


@auth_bp.post("/auth/register")
def register():
    if not security.rate_limit_check(f"register:{client_ip()}"):
        audit.log_event(audit.ACTION_RATE_LIMIT, outcome="failure",
                        details="register", ip_address=client_ip())
        return jsonify({"error": "Слишком много запросов"}), 429
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""
    if not username or len(username) < 3:
        return jsonify({"error": "Имя пользователя минимум 3 символа"}), 400
    ok, msg = security.password_strength_ok(password)
    if not ok:
        return jsonify({"error": msg}), 400
    if users.get_by_username(username):
        return jsonify({"error": "Пользователь уже существует"}), 409
    user = users.create_user(username, password, role="user")
    audit.log_event(audit.ACTION_REGISTER, username=username,
                    user_id=user["id"], ip_address=client_ip())
    access, session = _issue_tokens(user)
    resp = make_response(jsonify({"user": user, "session_id": session["session_id"]}), 201)
    return _set_auth_cookies(resp, access, session["refresh_token"], session["session_id"])


@auth_bp.post("/auth/challenge")
@csrf_protect
def challenge():
    if not security.rate_limit_check(f"challenge:{client_ip()}"):
        audit.log_event(audit.ACTION_RATE_LIMIT, outcome="failure",
                        details="challenge", ip_address=client_ip())
        return jsonify({"error": "Слишком много запросов"}), 429
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    raw = users.get_raw_by_username(username)
    # Одинаковая внешняя реакция: не раскрываем существование пользователя.
    if raw is None:
        fake = secrets.token_hex(16)
        return jsonify({"username": username, "challenge": fake})
    chal = secrets.token_hex(16)
    users.set_challenge(raw["id"], chal)
    return jsonify({"username": username, "challenge": chal})


@auth_bp.post("/auth/response")
@csrf_protect
def response():
    if not security.rate_limit_check(f"response:{client_ip()}"):
        audit.log_event(audit.ACTION_RATE_LIMIT, outcome="failure",
                        details="response", ip_address=client_ip())
        return jsonify({"error": "Слишком много запросов"}), 429
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    answer = data.get("response") or ""
    raw = users.get_raw_by_username(username)

    def fail():
        # Неуспешная попытка логируется даже для несуществующего пользователя.
        audit.log_event(audit.ACTION_LOGIN_FAILURE, outcome="failure",
                        username=username, ip_address=client_ip(),
                        details="challenge-response")
        return jsonify({"error": "Неверные учётные данные"}), 401

    if raw is None or not raw.get("challenge") or not raw.get("challenge_until"):
        return fail()
    from datetime import datetime, timezone
    try:
        until = datetime.fromisoformat(raw["challenge_until"])
    except (ValueError, TypeError):
        return fail()
    if until < datetime.now(timezone.utc):
        users.clear_challenge(raw["id"])
        return fail()
    if not raw.get("challenge_key"):
        return fail()
    expected = _derive_response_from_key(raw["challenge_key"], raw["challenge"])
    if not hmac.compare_digest(expected, answer):
        users.clear_challenge(raw["id"])
        return fail()
    if not raw.get("is_active"):
        return fail()
    users.clear_challenge(raw["id"])
    users.mark_login(raw["id"])
    user = users.get_by_id(raw["id"])
    access, session = _issue_tokens(user)
    audit.log_event(audit.ACTION_LOGIN_SUCCESS, username=username,
                    user_id=user["id"], ip_address=client_ip())
    resp = make_response(jsonify({"user": user, "session_id": session["session_id"]}))
    return _set_auth_cookies(resp, access, session["refresh_token"], session["session_id"])


@auth_bp.get("/users/me")
@require_auth
def me():
    return jsonify(users.get_by_id(g.current_user["id"]))


@auth_bp.post("/auth/refresh")
@csrf_protect
def refresh():
    session_id = request.cookies.get("session_id")
    refresh_token = request.cookies.get("refresh_token")
    if not session_id or not refresh_token:
        return jsonify({"error": "Нет refresh-сессии"}), 401
    session = security.validate_refresh(session_id, refresh_token)
    if not session:
        return jsonify({"error": "Сессия недействительна"}), 401
    user = users.get_by_id(session["user_id"])
    if not user or not user.get("is_active"):
        return jsonify({"error": "Пользователь недоступен"}), 401
    access = security.create_access_token(user, session_id)
    audit.log_event(audit.ACTION_TOKEN_REFRESH, username=user["username"],
                    user_id=user["id"], ip_address=client_ip())
    resp = make_response(jsonify({"user": user}))
    secure = not config.ALLOW_INSECURE
    resp.set_cookie("access_token", access, httponly=True, samesite="Lax",
                    secure=secure, max_age=config.ACCESS_TOKEN_TTL, path="/")
    return resp


@auth_bp.post("/auth/logout")
@csrf_protect
def logout():
    session_id = request.cookies.get("session_id")
    user = load_current_user()
    if session_id:
        security.revoke_session(session_id)
    if user:
        audit.log_event(audit.ACTION_LOGOUT, username=user["username"],
                        user_id=user["id"], ip_address=client_ip())
    resp = make_response(jsonify({"status": "ok"}))
    return _clear_auth_cookies(resp)


# ─────────────── Управление сессиями (шаг 6) ───────────────


@auth_bp.get("/auth/sessions")
@require_auth
def list_sessions():
    return jsonify(security.list_user_sessions(g.current_user["id"]))


@auth_bp.delete("/auth/sessions/<session_id>")
@require_auth
@csrf_protect
def revoke_session(session_id: str):
    security.revoke_session(session_id)
    audit.log_event(audit.ACTION_SESSION_REVOKE, username=g.current_user["username"],
                    user_id=g.current_user["id"], details=session_id, ip_address=client_ip())
    return jsonify({"status": "ok"})


@auth_bp.delete("/admin/users/<int:user_id>/sessions")
@require_role("admin")
@csrf_protect
def admin_revoke_user_sessions(user_id: int):
    count = security.revoke_all_user_sessions(user_id)
    audit.log_event(audit.ACTION_ADMIN_SESSION_REVOKE, username=g.current_user["username"],
                    user_id=g.current_user["id"], details=f"user_id={user_id} count={count}",
                    ip_address=client_ip())
    return jsonify({"revoked": count})
