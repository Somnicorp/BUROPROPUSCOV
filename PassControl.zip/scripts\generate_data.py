﻿"""Генератор демонстрационной базы данных SQLite."""
from __future__ import annotations

import random
import re
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


from backend.app import database, repository  # noqa: E402


LAST_NAMES = [
    "Иванов", "Петров", "Сидоров", "Кузнецов", "Смирнов", "Попов",
    "Васильев", "Соколов", "Михайлов", "Новиков", "Фёдоров", "Морозов",
    "Волков", "Алексеев", "Лебедев", "Семёнов", "Егоров", "Павлов",
    "Козлов", "Степанов", "Николаев", "Орлов", "Андреев", "Макаров",
]

FIRST_NAMES_M = [
    "Александр", "Сергей", "Дмитрий", "Андрей", "Алексей", "Максим",
    "Евгений", "Иван", "Артём", "Николай", "Михаил", "Роман",
]

FIRST_NAMES_F = [
    "Анна", "Мария", "Елена", "Ольга", "Татьяна", "Наталья",
    "Ирина", "Светлана", "Екатерина", "Юлия", "Дарья", "Ксения",
]

MIDDLE_NAMES_M = [
    "Александрович", "Сергеевич", "Дмитриевич", "Андреевич",
    "Алексеевич", "Максимович", "Евгеньевич", "Иванович",
]

MIDDLE_NAMES_F = [
    "Александровна", "Сергеевна", "Дмитриевна", "Андреевна",
    "Алексеевна", "Максимовна", "Евгеньевна", "Ивановна",
]

COMPANIES = [
    "ООО Ромашка", "АО ТехноПром", "ЗАО СтройИнвест", "ООО Логистик",
    "ПАО ЭнергоСеть", "ООО МедСервис", "АО АвтоТранс", "ООО ПищеПром",
    "ЗАО БанкРазвитие", "ООО ИТ-Решения",
]

ACCESS_POINT_NAMES = [
    "Главный вход", "Северные ворота", "Южные ворота", "Западный КПП",
    "Восточный КПП", "Склад №1", "Склад №2", "Цех А", "Цех Б",
    "Административное здание", "Столовая", "Парковка", "Лаборатория",
    "Серверная", "Архив", "Гараж", "Проходная №2", "Бюро пропусков",
    "Медпункт", "Спортзал",
]

TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e",
    "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l",
    "м": "m", "н": "n", "о": "o", "п": "p", "р": "r", "с": "s",
    "т": "t", "у": "u", "ф": "f", "х": "h", "ц": "c", "ч": "ch",
    "ш": "sh", "щ": "sch", "ъ": "", "ы": "y", "ь": "", "э": "e",
    "ю": "yu", "я": "ya",
}

# Счётчик для гарантированно уникальных номеров карт
_CARD_COUNTER = 0


def _tr(s: str) -> str:
    return "".join(TRANSLIT.get(c, c) for c in s.lower())


def _random_name(gender: str) -> str:
    last = random.choice(LAST_NAMES)
    if gender == "M":
        first = random.choice(FIRST_NAMES_M)
        middle = random.choice(MIDDLE_NAMES_M)
    else:
        first = random.choice(FIRST_NAMES_F)
        middle = random.choice(MIDDLE_NAMES_F)
    return f"{last} {first} {middle}"


def _random_phone() -> str:
    return f"+7{random.randint(900, 999)}{random.randint(1000000, 9999999)}"


def _random_email(fio: str) -> str:
    parts = re.findall(r"\w+", fio)
    if len(parts) >= 2:
        return f"{_tr(parts[0])}.{_tr(parts[1])}@example.com"
    return f"user{random.randint(1000, 9999)}@example.com"


def _unique_card_number(prefix: str = "CARD") -> str:
    """Гарантированно уникальный номер карты."""
    global _CARD_COUNTER
    _CARD_COUNTER += 1
    return f"{prefix}-{_CARD_COUNTER:08d}"


def _table_columns(conn: sqlite3.Connection, table: str) -> set:
    """Возвращает множество колонок таблицы."""
    cur = conn.execute(f"PRAGMA table_info({table})")
    return {row[1] for row in cur.fetchall()}


def generate_holders(count: int = 1200) -> list:
    ids = []
    for _ in range(count):
        gender = random.choice(["M", "F"])
        fio = _random_name(gender)
        data = {
            "full_name": fio,
            "company": random.choice(COMPANIES),
            "position": random.choice([
                "Инженер", "Менеджер", "Бухгалтер", "Водитель", "Охранник",
                "Уборщик", "Электрик", "Слесарь", "Программист", "Директор",
            ]),
            "phone": _random_phone(),
            "email": _random_email(fio),
            "photo_path": None,
        }
        holder = repository.create_holder(data)
        ids.append(holder["id"])
    return ids


def generate_access_points(count: int = 20) -> list:
    ids = []
    for name in ACCESS_POINT_NAMES[:count]:
        ap = repository.create_access_point({
            "name": name,
            "location": random.choice(["Корпус А", "Корпус Б", "Территория", "Периметр"]),
            "description": f"Точка доступа: {name}",
        })
        ids.append(ap["id"])
    return ids


def generate_passes(holder_ids: list, count: int = 5000) -> list:
    """Генерирует пропуска, подстраиваясь под реальную схему таблицы passes."""
    from backend.app import config
    conn = sqlite3.connect(str(config.DB_PATH))
    cols = _table_columns(conn, "passes")
    conn.close()

    ids = []
    now = datetime.utcnow()

    for _ in range(count):
        holder_id = random.choice(holder_ids)
        issued = now - timedelta(days=random.randint(1, 365))
        valid_until = issued + timedelta(days=random.choice([30, 90, 180, 365]))
        status = random.choice(["active", "active", "active", "expired", "blocked"])
        if valid_until < now and status == "active":
            status = "expired"

        data = {
            "holder_id": holder_id,
            "card_number": _unique_card_number(),
            "status": status,
        }

        # Подставляем поля по реальной схеме
        if "pass_type" in cols:
            data["pass_type"] = random.choice(["permanent", "temporary", "visitor"])
        if "zone" in cols:
            data["zone"] = random.choice(["A", "B", "C", "D", "perimeter"])
        if "issued_at" in cols:
            data["issued_at"] = issued.isoformat()
        if "valid_from" in cols:
            data["valid_from"] = issued.date().isoformat()
        if "valid_until" in cols:
            data["valid_until"] = valid_until.isoformat()
        if "valid_to" in cols:
            data["valid_to"] = valid_until.date().isoformat()

        try:
            p = repository.create_pass(data)
        except Exception as exc:
            # Пропускаем проблемные записи, чтобы не падать на середине
            print(f"    [warn] пропуск: {exc}")
            continue
        ids.append(p["id"])

    return ids


def generate_access_logs(pass_ids: list, ap_ids: list, count: int = 4000) -> None:
    if not pass_ids or not ap_ids:
        print("    [warn] нет пропусков или точек доступа — логи не генерируются")
        return

    from backend.app import config
    conn = sqlite3.connect(str(config.DB_PATH))
    cols = _table_columns(conn, "access_logs")
    conn.close()

    now = datetime.utcnow()
    for _ in range(count):
        pass_id = random.choice(pass_ids)
        ap_id = random.choice(ap_ids)
        result = random.choice(["granted", "granted", "granted", "denied"])
        ts = now - timedelta(
            days=random.randint(0, 30),
            hours=random.randint(0, 23),
            minutes=random.randint(0, 59),
        )

        data = {
            "pass_id": pass_id,
            "access_point_id": ap_id,
            "result": result,
            "timestamp": ts.isoformat(),
            "reason": None if result == "granted" else "просрочен или заблокирован",
        }

        try:
            repository.log_access(data)
        except Exception as exc:
            print(f"    [warn] лог: {exc}")
            continue


def create_default_users() -> None:
    from backend.app import users
    defaults = [
        ("admin", "Admin123!", "admin"),
        ("manager", "Manager123!", "manager"),
        ("user", "User123!", "user"),
        ("guest", "Guest123!", "guest"),
    ]
    for username, password, role in defaults:
        try:
            existing = users.get_user_by_username(username)
        except Exception:
            existing = None
        if existing:
            continue
        try:
            users.create_user(username, password, role=role)
            print(f"    {username} / {password}")
        except TypeError:
            users.create_user(username=username, password=password, role=role)
            print(f"    {username} / {password}")


def main() -> int:
    from backend.app import config

    print(f"Создание БД SQLite: {config.DB_PATH}")
    database.init_db()

    random.seed(42)

    print("  Владельцев:      ", end="", flush=True)
    holder_ids = generate_holders(1200)
    print(len(holder_ids))

    print("  Точек доступа:   ", end="", flush=True)
    ap_ids = generate_access_points(20)
    print(len(ap_ids))

    print("  Пропусков:       ", end="", flush=True)
    pass_ids = generate_passes(holder_ids, 5000)
    print(len(pass_ids))

    print("  Записей проходов:", end="", flush=True)
    generate_access_logs(pass_ids, ap_ids, 4000)
    print(4000)

    print("  Пользователи:")
    create_default_users()

    print()
    print("[OK] База данных создана.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
