﻿"""Подпись и проверка исходящих документов (шаг 5).

Совместим с api.py: предоставляет public_key_pem(), sign_document(), verify_document().
Ключи — keys/signing_key.pem и keys/signing_public.pem.
"""
from __future__ import annotations

import base64
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, padding, rsa


def _load_private_key(path: Path):
    if not path.exists():
        raise FileNotFoundError(f"Приватный ключ не найден: {path}")
    return serialization.load_pem_private_key(path.read_bytes(), password=None)


def _load_public_key(path: Path):
    if not path.exists():
        raise FileNotFoundError(f"Публичный ключ не найден: {path}")
    return serialization.load_pem_public_key(path.read_bytes())


def _hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _canonical_json(obj: Any) -> bytes:
    return json.dumps(
        obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")


def _sign_bytes(private_key, data: bytes) -> bytes:
    if isinstance(private_key, ec.EllipticCurvePrivateKey):
        return private_key.sign(data, ec.ECDSA(hashes.SHA256()))
    if isinstance(private_key, rsa.RSAPrivateKey):
        return private_key.sign(
            data,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()),
                        salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256(),
        )
    raise TypeError(f"Неподдерживаемый тип ключа: {type(private_key)}")


def _verify_bytes(public_key, signature: bytes, data: bytes) -> bool:
    try:
        if isinstance(public_key, ec.EllipticCurvePublicKey):
            public_key.verify(signature, data, ec.ECDSA(hashes.SHA256()))
        elif isinstance(public_key, rsa.RSAPublicKey):
            public_key.verify(
                signature, data,
                padding.PSS(mgf=padding.MGF1(hashes.SHA256()),
                            salt_length=padding.PSS.MAX_LENGTH),
                hashes.SHA256(),
            )
        else:
            raise TypeError(f"Неподдерживаемый тип ключа: {type(public_key)}")
        return True
    except InvalidSignature:
        return False


def public_key_pem(private_key_path: Path | None = None,
                   public_key_path: Path | None = None) -> str:
    """Отдаёт публичный ключ в PEM. Если файла нет — генерирует пару из приватного."""
    from . import config
    public_path = public_key_path or config.SIGNING_PUBLIC_KEY_PATH
    private_path = private_key_path or config.SIGNING_PRIVATE_KEY_PATH

    if public_path.exists():
        return public_path.read_text(encoding="utf-8")

    # Если публичного нет — сгенерируем из приватного
    if not private_path.exists():
        return ""

    private_key = _load_private_key(private_path)
    pem = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("ascii")
    public_path.write_text(pem, encoding="utf-8")
    return pem


def sign_document(
    document: Any,
    *,
    signed_by: str,
    private_key_path: Path | None = None,
    document_type: str = "passes_export",
) -> dict:
    """Подписывает документ. Возвращает конверт с подписью."""
    from . import config
    path = private_key_path or config.SIGNING_PRIVATE_KEY_PATH
    private_key = _load_private_key(path)

    payload = _canonical_json(document)
    content_hash = _hash(payload)

    metadata = {
        "document_type": document_type,
        "signed_by": signed_by,
        "signed_at": datetime.now(timezone.utc).isoformat(),
        "content_sha256": content_hash,
    }
    to_sign = _canonical_json({"document": document, "metadata": metadata})
    signature = _sign_bytes(private_key, to_sign)

    if isinstance(private_key, ec.EllipticCurvePrivateKey):
        algorithm = f"ECDSA-{private_key.curve.name}-SHA256"
    else:
        algorithm = f"RSA-{private_key.key_size}-PSS-SHA256"

    return {
        "document": document,
        "metadata": metadata,
        "signature": base64.b64encode(signature).decode("ascii"),
        "algorithm": algorithm,
    }


def verify_document(envelope: dict, *,
                    public_key_path: Path | None = None) -> dict:
    """Проверяет подпись документа. Возвращает dict с valid/reason/metadata."""
    from . import config
    path = public_key_path or config.SIGNING_PUBLIC_KEY_PATH

    try:
        document = envelope["document"]
        metadata = envelope["metadata"]
        signature_b64 = envelope["signature"]
    except (KeyError, TypeError) as exc:
        return {"valid": False, "reason": f"Неверный формат конверта: {exc}"}

    try:
        signature = base64.b64decode(signature_b64)
    except Exception as exc:
        return {"valid": False, "reason": f"Некорректная base64-подпись: {exc}"}

    payload = _canonical_json(document)
    actual_hash = _hash(payload)
    expected_hash = metadata.get("content_sha256")

    if actual_hash != expected_hash:
        return {
            "valid": False,
            "reason": "Документ изменён после подписи (хеш не совпадает)",
            "metadata": metadata,
            "expected_hash": expected_hash,
            "actual_hash": actual_hash,
        }

    try:
        public_key = _load_public_key(path)
    except FileNotFoundError as exc:
        return {"valid": False, "reason": str(exc), "metadata": metadata}

    to_verify = _canonical_json({"document": document, "metadata": metadata})
    if not _verify_bytes(public_key, signature, to_verify):
        return {"valid": False, "reason": "Подпись недействительна",
                "metadata": metadata}

    return {"valid": True, "reason": "Подпись верна", "metadata": metadata}


# =====================================================================
#  Обёртки с "правильными" именами (для совместимости с api.py)
# =====================================================================

def sign_passes(items: list, signed_by: str = "system") -> dict:
    """Обёртка: подписать список пропусков."""
    return sign_document(items, signed_by=signed_by,
                         document_type="passes_export")


def verify_signature(envelope: dict) -> dict:
    """Обёртка: проверить подпись конверта."""
    return verify_document(envelope)


# =====================================================================
#  Обёртки с "правильными" именами (для совместимости с api.py)
# =====================================================================

def sign_passes(items: list, signed_by: str = "system") -> dict:
    """Обёртка: подписать список пропусков."""
    return sign_document(items, signed_by=signed_by,
                         document_type="passes_export")


def verify_signature(envelope: dict) -> dict:
    """Обёртка: проверить подпись конверта."""
    return verify_document(envelope)
