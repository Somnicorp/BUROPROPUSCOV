"""Отечественные криптоалгоритмы (ГОСТ) через библиотеку gostcrypto.

Реализованы:
  * Кузнечик - ГОСТ Р 34.12-2015 (блочный шифр 128 бит, ключ 256 бит);
  * Магма    - ГОСТ 28147-89 / ГОСТ Р 34.12-2015 (блочный шифр 64 бита);
  * Стрибог  - ГОСТ Р 34.11-2012 (хеш-функция 256 бит).

Модуль даёт удобную обёртку над gostcrypto:
  * шифрование/расшифровка строк в режиме CTR (гаммирование);
  * хеширование Стрибог-256 в hex-виде, совместимом с RFC 6986;
  * вывод 256-битного ключа из произвольного секрета.

gostcrypto - чистый Python без бинарных зависимостей, что удобно
для аудита ИБ и не требует компиляторов при установке.
"""
from __future__ import annotations

import base64
import os as _os

from gostcrypto import gostcipher, gosthash

# Идентификатор алгоритма по умолчанию.
DEFAULT_ALGORITHM = "kuznyechik"

# gostcrypto в некоторых версиях использует написание 'kuznechik'
# (без 'y'), поэтому нормализуем имя алгоритма перед вызовом.
_ALGO_ALIASES = {
    "kuznyechik": "kuznechik",
    "kuznechik": "kuznechik",
    "magma": "magma",
}


def _algo(name: str) -> str:
    return _ALGO_ALIASES.get(name, name)

# Префикс для шифротекста, чтобы различать ГОСТ-значения в БД.
GOST_PREFIX = "gost:"


# =====================================================================
#  Хеширование - Стрибог (ГОСТ Р 34.11-2012)
# =====================================================================


def stribog256(data: bytes) -> bytes:
    """Хеш Стрибог-256. Возвращает 32 байта в порядке RFC 6986."""
    hasher = gosthash.new("streebog256")
    hasher.update(bytearray(data))
    # gostcrypto отдаёт байты в обратном порядке относительно RFC,
    # поэтому разворачиваем для совместимости с эталонными тестами.
    return bytes(hasher.digest())[::-1]


def stribog256_hex(data: bytes) -> str:
    """Хеш Стрибог-256 в hex-виде (совместим с RFC 6986)."""
    return stribog256(data).hex()


def derive_key_256(secret: bytes) -> bytes:
    """Детерминированно выводит 256-битный ключ из произвольного секрета."""
    if len(secret) >= 32:
        return secret[:32]
    return stribog256(secret)


# =====================================================================
#  Симметричное шифрование - Кузнечик / Магма
# =====================================================================


def _normalize_key(key: bytes) -> bytearray:
    """Приводит ключ к bytearray длиной 32 байта."""
    if isinstance(key, (bytes, bytearray)):
        raw = bytes(key)
    elif isinstance(key, str):
        raw = key.encode("utf-8")
    else:
        raise TypeError("Ключ должен быть bytes, bytearray или str")
    if len(raw) != 32:
        raw = derive_key_256(raw)
    return bytearray(raw)


def encrypt_bytes(plaintext: bytes, key: bytes, algorithm: str = DEFAULT_ALGORITHM) -> bytes:
    """Шифрует данные в режиме CTR. Возвращает nonce(8) + шифротекст."""
    if not plaintext:
        return b""
    k = _normalize_key(key)
    algo = _algo(algorithm)
    nonce_len = 8 if algo == "kuznechik" else 4
    iv = bytearray(_os.urandom(nonce_len))
    cipher = gostcipher.new(algo, k, gostcipher.MODE_CTR, init_vect=iv)
    body = cipher.encrypt(bytearray(plaintext))
    return bytes(iv) + bytes(body)


def decrypt_bytes(ciphertext: bytes, key: bytes, algorithm: str = DEFAULT_ALGORITHM) -> bytes:
    """Расшифровывает данные, зашифрованные encrypt_bytes."""
    if not ciphertext:
        return b""
    k = _normalize_key(key)
    algo = _algo(algorithm)
    nonce_len = 8 if algo == "kuznechik" else 4
    if len(ciphertext) < nonce_len:
        raise ValueError("Слишком короткий шифротекст")
    iv = bytearray(ciphertext[:nonce_len])
    body = bytearray(ciphertext[nonce_len:])
    cipher = gostcipher.new(algo, k, gostcipher.MODE_CTR, init_vect=iv)
    return bytes(cipher.decrypt(body))


def encrypt_str(plaintext: str, key: bytes, algorithm: str = DEFAULT_ALGORITHM) -> str:
    """Шифрует строку и возвращает base64-строку с префиксом gost:."""
    if plaintext is None:
        return None
    data = str(plaintext).encode("utf-8")
    token = encrypt_bytes(data, key, algorithm)
    return GOST_PREFIX + base64.b64encode(token).decode("ascii")


def decrypt_str(token: str, key: bytes, algorithm: str = DEFAULT_ALGORITHM) -> str:
    """Расшифровывает строку, созданную encrypt_str."""
    if token is None:
        return None
    if not isinstance(token, str) or not token.startswith(GOST_PREFIX):
        # Значение не зашифровано ГОСТ - возвращаем как есть (совместимость).
        return token
    raw = base64.b64decode(token[len(GOST_PREFIX):])
    return decrypt_bytes(raw, key, algorithm).decode("utf-8")


def is_gost_token(value) -> bool:
    """Проверяет, является ли значение ГОСТ-шифротекстом."""
    return isinstance(value, str) and value.startswith(GOST_PREFIX)
