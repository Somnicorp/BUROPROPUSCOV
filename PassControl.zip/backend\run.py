﻿"""Запуск сервера системы учёта и проверки пропусков.

По умолчанию использует waitress (production WSGI-сервер).
Для отладки: python backend/run.py --debug
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


def main() -> int:
    parser = argparse.ArgumentParser(description="Сервер системы учёта пропусков")
    parser.add_argument("--debug", action="store_true", help="режим отладки Flask")
    parser.add_argument("--host", default=None, help="хост")
    parser.add_argument("--port", type=int, default=None, help="порт")
    parser.add_argument("--generate", action="store_true",
                        help="сгенерировать БД и выйти")
    args = parser.parse_args()

    from backend.app import config

    if args.generate:
        import subprocess
        script = PROJECT_ROOT / "scripts" / "generate_data.py"
        return subprocess.call([sys.executable, str(script)])

    from backend.app.main import app

    host = args.host or config.HOST
    port = args.port or config.PORT
    debug = args.debug or config.DEBUG

    if debug:
        print(f"[*] Flask dev-сервер на http://{host}:{port}")
        app.run(host=host, port=port, debug=True)
    else:
        from waitress import serve
        print(f"[*] Waitress на http://{host}:{port}")
        serve(app, host=host, port=port, threads=8)

    return 0


if __name__ == "__main__":
    sys.exit(main())
