"""Декораторы доступа для API (реэкспорт из auth, чтобы избежать
циклических импортов между api и auth)."""
from __future__ import annotations

from .auth import (  # noqa: F401
    csrf_protect,
    load_current_user,
    require_auth,
    require_role,
)

__all__ = ["csrf_protect", "load_current_user", "require_auth", "require_role"]
