﻿"""REST API СЃРёСЃС‚РµРјС‹ СѓС‡С‘С‚Р° Рё РїСЂРѕРІРµСЂРєРё РїСЂРѕРїСѓСЃРєРѕРІ (Flask Blueprint).

Р‘Р°Р·РѕРІС‹Р№ РїСЂРµС„РёРєСЃ: /api/v1

RBAC (С€Р°Рі 2) РїСЂРёРјРµРЅСЏРµС‚СЃСЏ СЃРµСЂРІРµСЂРЅРѕ С‡РµСЂРµР· РґРµРєРѕСЂР°С‚РѕСЂС‹ require_role.
РџСѓР±Р»РёС‡РЅС‹Рµ СЌРЅРґРїРѕРёРЅС‚С‹: /health, /public/info.
РЈРїСЂР°РІР»РµРЅРёРµ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏРјРё Рё Р¶СѓСЂРЅР°Р»РѕРј Р°СѓРґРёС‚Р° - С‚РѕР»СЊРєРѕ admin.
Р­РєСЃРїРѕСЂС‚ СЃ РїРѕРґРїРёСЃСЊСЋ - С€Р°Рі 5.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

from flask import Blueprint, Response, g, jsonify, request

from . import __version__, audit, crypto, services
from .api_deps import csrf_protect, require_auth, require_role
from .services import ConflictError, NotFoundError, ValidationError

api = Blueprint("api", __name__, url_prefix="/api/v1")


def _error(message: str, status: int):
    return jsonify({"error": message}), status


def _handle(fn, *args, success_status: int = 200, **kwargs):
    """Р•РґРёРЅР°СЏ РѕР±СЂР°Р±РѕС‚РєР° РѕС€РёР±РѕРє СЃРµСЂРІРёСЃРЅРѕРіРѕ СЃР»РѕСЏ.

    success_status Р·Р°РґР°С‘С‚ РєРѕРґ СѓСЃРїРµС€РЅРѕРіРѕ РѕС‚РІРµС‚Р° (201 РґР»СЏ СЃРѕР·РґР°РЅРёСЏ).
    """
    try:
        result = fn(*args, **kwargs)
    except ValidationError as exc:
        return _error(str(exc), 400)
    except NotFoundError as exc:
        return _error(str(exc), 404)
    except ConflictError as exc:
        return _error(str(exc), 409)
    if result is None:
        return "", 204
    return jsonify(result), success_status


# в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ РџСѓР±Р»РёС‡РЅС‹Рµ в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ


@api.get("/health")
def health():
    return jsonify({"status": "ok", "app": "Pass Control API", "version": __version__})


@api.get("/public/info")
def public_info():
    """Р”РѕСЃС‚СѓРїРЅРѕ РІСЃРµРј (РІРєР»СЋС‡Р°СЏ РіРѕСЃС‚СЏ) - РѕР±С‰Р°СЏ РёРЅС„РѕСЂРјР°С†РёСЏ Рѕ СЃРёСЃС‚РµРјРµ."""
    s = services.stats()
    return jsonify({
        "app": "РЎРёСЃС‚РµРјР° СѓС‡С‘С‚Р° Рё РїСЂРѕРІРµСЂРєРё РїСЂРѕРїСѓСЃРєРѕРІ",
        "version": __version__,
        "total_passes": s["total_passes"],
        "total_access_points": s["total_access_points"],
    })


# в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ РџСЂРѕС„РёР»СЊ в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ


@api.get("/user/profile")
@require_auth
def profile():
    return jsonify({"user": g.current_user})


# в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ РЎС‚Р°С‚РёСЃС‚РёРєР° в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ


@api.get("/stats")
@require_role("user")
def stats():
    return jsonify(services.stats())


# в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ Р’Р»Р°РґРµР»СЊС†С‹ в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ


@api.get("/holders")
@require_role("user")
def list_holders():
    return jsonify(services.list_holders())


@api.post("/holders")
@require_role("manager")
@csrf_protect
def create_holder():
    payload = request.get_json(silent=True) or {}
    return _handle(services.create_holder, payload, success_status=201)


@api.get("/holders/<int:holder_id>")
@require_role("user")
def get_holder(holder_id: int):
    return _handle(services.get_holder, holder_id)


@api.patch("/holders/<int:holder_id>")
@require_role("manager")
@csrf_protect
def update_holder(holder_id: int):
    payload = request.get_json(silent=True) or {}
    return _handle(services.update_holder, holder_id, payload)


@api.delete("/holders/<int:holder_id>")
@require_role("admin")
@csrf_protect
def delete_holder(holder_id: int):
    return _handle(services.delete_holder, holder_id)


# в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ РўРѕС‡РєРё РґРѕСЃС‚СѓРїР° в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ


@api.get("/access-points")
@require_role("guest")
def list_access_points():
    return jsonify(services.list_access_points())


@api.post("/access-points")
@require_role("manager")
@csrf_protect
def create_access_point():
    payload = request.get_json(silent=True) or {}
    return _handle(services.create_access_point, payload, success_status=201)


@api.get("/access-points/<int:point_id>")
@require_role("guest")
def get_access_point(point_id: int):
    return _handle(services.get_access_point, point_id)


@api.patch("/access-points/<int:point_id>")
@require_role("manager")
@csrf_protect
def update_access_point(point_id: int):
    payload = request.get_json(silent=True) or {}
    return _handle(services.update_access_point, point_id, payload)


@api.delete("/access-points/<int:point_id>")
@require_role("admin")
@csrf_protect
def delete_access_point(point_id: int):
    return _handle(services.delete_access_point, point_id)


# в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ РџСЂРѕРїСѓСЃРєР° в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ


@api.get("/passes")
@require_role("user")
def list_passes():
    status = request.args.get("status")
    holder_id = request.args.get("holder_id", type=int)
    return jsonify(services.list_passes(status=status, holder_id=holder_id))


@api.post("/passes")
@require_role("manager")
@csrf_protect
def create_pass():
    payload = request.get_json(silent=True) or {}
    return _handle(services.create_pass, payload, success_status=201)


@api.get("/passes/<int:pass_id>")
@require_role("user")
def get_pass(pass_id: int):
    return _handle(services.get_pass, pass_id)


@api.patch("/passes/<int:pass_id>")
@require_role("manager")
@csrf_protect
def update_pass(pass_id: int):
    payload = request.get_json(silent=True) or {}
    return _handle(services.update_pass, pass_id, payload)


@api.delete("/passes/<int:pass_id>")
@require_role("admin")
@csrf_protect
def delete_pass(pass_id: int):
    return _handle(services.delete_pass, pass_id)


@api.post("/passes/verify")
@require_role("user")
@csrf_protect
def verify_pass():
    payload = request.get_json(silent=True) or {}
    card_number = payload.get("card_number")
    point_id = payload.get("access_point_id")
    direction = payload.get("direction", "entry")
    if not card_number or point_id is None:
        return _error("РџРѕР»СЏ card_number Рё access_point_id РѕР±СЏР·Р°С‚РµР»СЊРЅС‹", 400)
    return _handle(services.verify_pass, card_number, point_id, direction)


# в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ Р–СѓСЂРЅР°Р» РїСЂРѕС…РѕРґРѕРІ в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ


@api.get("/logs")
@require_role("user")
def list_logs():
    limit = request.args.get("limit", 200, type=int)
    return jsonify(services.list_logs(limit=limit))


# в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ РђСѓРґРёС‚ (С€Р°Рі 3, С‚РѕР»СЊРєРѕ admin) в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ


@api.get("/admin/logs")
@require_role("admin")
def admin_logs():
    limit = request.args.get("limit", 200, type=int)
    return jsonify({
        "logs": audit.list_logs(limit=limit),
        "chain": audit.verify_chain(),
    })


# в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ РЈРїСЂР°РІР»РµРЅРёРµ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏРјРё (С€Р°Рі 2, admin) в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ


@api.get("/admin/users")
@require_role("admin")
def admin_list_users():
    from . import users
    return jsonify(users.list_users())


@api.post("/admin/users")
@require_role("admin")
@csrf_protect
def admin_create_user():
    from . import users
    payload = request.get_json(silent=True) or {}
    username = (payload.get("username") or "").strip()
    password = payload.get("password") or ""
    role = payload.get("role") or "user"
    if not username or len(username) < 3:
        return _error("РРјСЏ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ РјРёРЅРёРјСѓРј 3 СЃРёРјРІРѕР»Р°", 400)
    from . import security
    ok, msg = security.password_strength_ok(password)
    if not ok:
        return _error(msg, 400)
    if users.get_by_username(username):
        return _error("РџРѕР»СЊР·РѕРІР°С‚РµР»СЊ СѓР¶Рµ СЃСѓС‰РµСЃС‚РІСѓРµС‚", 409)
    try:
        user = users.create_user(username, password, role)
    except ValueError as exc:
        return _error(str(exc), 400)
    audit.log_event(audit.ACTION_ADMIN_USER_CREATE, username=g.current_user["username"],
                    user_id=g.current_user["id"], details=f"created={username} role={role}")
    return jsonify(user), 201


@api.patch("/admin/users/<int:user_id>/role")
@require_role("admin")
@csrf_protect
def admin_change_role(user_id: int):
    from . import users
    payload = request.get_json(silent=True) or {}
    role = payload.get("role")
    try:
        user = users.update_role(user_id, role)
    except ValueError as exc:
        return _error(str(exc), 400)
    if user is None:
        return _error("РџРѕР»СЊР·РѕРІР°С‚РµР»СЊ РЅРµ РЅР°Р№РґРµРЅ", 404)
    audit.log_event(audit.ACTION_ADMIN_ROLE_CHANGE, username=g.current_user["username"],
                    user_id=g.current_user["id"], details=f"target={user_id} role={role}")
    return jsonify(user)


@api.delete("/admin/users/<int:user_id>")
@require_role("admin")
@csrf_protect
def admin_delete_user(user_id: int):
    from . import users
    if int(g.current_user["id"]) == int(user_id):
        return _error("РќРµР»СЊР·СЏ СѓРґР°Р»РёС‚СЊ СЃР°РјРѕРіРѕ СЃРµР±СЏ", 400)
    if not users.delete_user(user_id):
        return _error("РџРѕР»СЊР·РѕРІР°С‚РµР»СЊ РЅРµ РЅР°Р№РґРµРЅ", 404)
    audit.log_event(audit.ACTION_ADMIN_USER_DELETE, username=g.current_user["username"],
                    user_id=g.current_user["id"], details=f"deleted={user_id}")
    return "", 204


# в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ Р­РєСЃРїРѕСЂС‚ СЃ РїРѕРґРїРёСЃСЊСЋ (С€Р°Рі 5) в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ


@api.get("/export/passes")
@require_role("manager")
def export_passes():
    """Р­РєСЃРїРѕСЂС‚ РїСЂРѕРїСѓСЃРєРѕРІ СЃ СЌР»РµРєС‚СЂРѕРЅРЅРѕР№ РїРѕРґРїРёСЃСЊСЋ (ECDSA + SHA-256)."""
    passes = services.list_passes()
    document = {
        "type": "passes_export",
        "generated_by": g.current_user["username"],
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "count": len(passes),
        "items": passes,
    }
    content = json.dumps(document, ensure_ascii=False, sort_keys=True).encode("utf-8")
    envelope = crypto.sign_document(content, meta={
        "type": document["type"],
        "generated_by": document["generated_by"],
        "generated_at": document["generated_at"],
        "count": document["count"],
    })
    audit.log_event(audit.ACTION_EXPORT_SIGNED, username=g.current_user["username"],
                    user_id=g.current_user["id"], details=f"passes count={len(passes)}")
    signed = {
        "document": document,
        "signature": envelope,
    }
    return jsonify(signed)


@api.post("/verify/signature")
@require_role("user")
@csrf_protect
def verify_signature():
    """РџСЂРѕРІРµСЂРєР° РїРѕРґРїРёСЃРё РґРѕРєСѓРјРµРЅС‚Р°: РїРѕРґРїРёСЃСЊ РІРµСЂРЅР° / РґРѕРєСѓРјРµРЅС‚ РёР·РјРµРЅС‘РЅ."""
    payload = request.get_json(silent=True) or {}
    document = payload.get("document")
    envelope = payload.get("signature")
    if document is None or not envelope:
        return _error("РќСѓР¶РЅС‹ РїРѕР»СЏ document Рё signature", 400)
    content = json.dumps(document, ensure_ascii=False, sort_keys=True).encode("utf-8")
    valid = crypto.verify_document(content, envelope)
    return jsonify({
        "valid": valid,
        "status": "РїРѕРґРїРёСЃСЊ РІРµСЂРЅР°" if valid else "РґРѕРєСѓРјРµРЅС‚ РёР·РјРµРЅС‘РЅ РїРѕСЃР»Рµ РїРѕРґРїРёСЃРё",
    })


@api.get("/signing/public-key")
@require_role("user")
def signing_public_key():
    return Response(crypto.public_key_pem(), mimetype="text/plain")


# =====================================================================
