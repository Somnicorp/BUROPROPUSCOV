#!/usr/bin/env bash
cd "$(dirname "$0")"

if [ -f ".server.pid" ]; then
    PID=$(cat .server.pid)
    if kill -0 "$PID" 2>/dev/null; then
        echo "[*] Остановка сервера (PID $PID)..."
        kill "$PID"
        rm -f .server.pid
        echo "[*] Сервер остановлен."
    else
        echo "[*] Процесс $PID уже не работает. Удаляю .server.pid."
        rm -f .server.pid
    fi
else
    echo "[*] .server.pid не найден. Сервер не запущен через install.sh."
fi