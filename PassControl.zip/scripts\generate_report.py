﻿"""Генерация Word-документа с поэтапным отчётом по шагам 0-6.

Запуск из корня проекта:
    python scripts/generate_report.py
Результат:
    Отчёт_FlaskPassControl.docx в корне проекта.
"""
from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt


PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

OUTPUT = str(PROJECT_ROOT / "Отчёт_FlaskPassControl.docx")


def add_heading(doc, text, level=1):
    return doc.add_heading(text, level=level)


def add_para(doc, text, bold=False, italic=False):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    return p


def add_bullets(doc, items):
    for item in items:
        doc.add_paragraph(item, style="List Bullet")


def add_table(doc, headers, rows):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Light Grid Accent 1"
    hdr = table.rows[0].cells
    for i, h in enumerate(headers):
        hdr[i].text = h
    for row in rows:
        cells = table.add_row().cells
        for i, val in enumerate(row):
            cells[i].text = str(val)
    return table


def build_document():
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)

    # ---------- Титульный лист ----------
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("\n\n\nСИСТЕМА УЧЁТА И ПРОВЕРКИ ПРОПУСКОВ\n")
    run.bold = True
    run.font.size = Pt(24)

    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run("Поэтапный отчёт по шагам 0-6\n")
    run.font.size = Pt(16)
    run.italic = True

    doc.add_paragraph("\n\n")
    info = doc.add_paragraph()
    info.alignment = WD_ALIGN_PARAGRAPH.CENTER
    info.add_run("Вариант 7 - рукопожатие (challenge-response)\n").bold = True
    info.add_run(f"Дата: {datetime.now().strftime('%d.%m.%Y')}\n")
    info.add_run("Стек: Flask + SQLite + ГОСТ-крипто + подпись документов\n")

    doc.add_page_break()

    # ---------- Оглавление ----------
    add_heading(doc, "Оглавление", level=1)
    add_bullets(doc, [
        "Введение",
        "Шаг 0. Базовое приложение (Excel -> SQLite)",
        "Шаг 1. Аутентификация (вариант 7 - рукопожатие)",
        "Шаг 2. RBAC - роли и разграничение доступа",
        "Шаг 3. Протоколирование и аудит",
        "Шаг 4. Криптография (Fernet + ГОСТ)",
        "Шаг 5. Подлинность исходящих документов",
        "Шаг 6. Управление сессиями и защита от веб-атак",
        "Инфраструктура: Docker Compose",
        "Заключение",
    ])
    doc.add_page_break()

    # ---------- Введение ----------
    add_heading(doc, "Введение", level=1)
    add_para(doc,
        "Проект представляет собой приложение для контроля и проверки пропусков "
        "на предприятии. Поверх базового приложения (шаг 0) последовательно "
        "реализованы: аутентификация, RBAC, аудит, криптография, подпись "
        "исходящих документов и защита от типовых веб-атак."
    )
    add_para(doc, "Используемый стек:", bold=True)
    add_bullets(doc, [
        "Бэкенд: Flask 3.1, waitress (WSGI), SQLite",
        "Аутентификация: challenge-response, bcrypt, JWT (PyJWT)",
        "Криптография: cryptography (Fernet/AES), gostcrypto (Кузнечик, Стрибог)",
        "Подпись: RSA/ECDSA + SHA-256",
        "Фронтенд: SPA на чистом JS, httpOnly cookie, CSRF-токен",
        "Инфраструктура: Docker Compose",
    ])

    # ---------- Шаг 0 ----------
    doc.add_page_break()
    add_heading(doc, "Шаг 0. Базовое приложение", level=1)
    add_para(doc, "Цель: перевести хранилище с Excel на SQLite и подготовить структуру проекта.", bold=True)
    add_para(doc, "Что сделано:")
    add_bullets(doc, [
        "Excel-хранилище (excel_db.py) заменено на SQLite (backend/app/database.py).",
        "Создан слой репозитория (backend/app/repository.py) с CRUD для holders, access_points, passes, access_logs.",
        "Транзакционная целостность (ACID) вместо атомарной перезаписи .xlsx.",
        "Генератор данных (scripts/generate_data.py) переписан под SQLite.",
        "Файл БД: data/pass_control.sqlite3.",
        "Проект разделён на backend/, frontend/, scripts/.",
    ])
    add_para(doc, "Схема БД:")
    add_table(doc,
        ["Таблица", "Назначение"],
        [
            ["holders", "Владельцы пропусков (ФИО, компания, email, phone)"],
            ["access_points", "Точки доступа (КПП)"],
            ["passes", "Пропуска (номер карты, зона, срок действия, статус)"],
            ["access_logs", "Журнал проходов"],
            ["users", "Пользователи системы (username, bcrypt-хеш, роль)"],
            ["sessions", "Активные сессии (refresh-token, IP, устройство)"],
            ["audit_logs", "Журнал событий ИБ с хеш-цепочкой"],
        ],
    )

    # ---------- Шаг 1 ----------
    doc.add_page_break()
    add_heading(doc, "Шаг 1. Аутентификация (вариант 7 - рукопожатие)", level=1)
    add_para(doc, "Цель: регистрация и вход по методу рукопожатия (challenge-response).", bold=True)
    add_para(doc, "Схема работы:")
    add_bullets(doc, [
        "POST /api/auth/challenge {username} - сервер возвращает challenge.",
        "Клиент вычисляет response = HMAC-SHA256(challenge, key=SHA256(password)).",
        "POST /api/auth/response {username, response} - сервер проверяет и выдаёт токен.",
        "Access-token (JWT, 15 мин) и refresh-token - в httpOnly cookie.",
    ])
    add_para(doc, "API:")
    add_table(doc,
        ["Метод", "Эндпоинт", "Назначение"],
        [
            ["POST", "/api/auth/register", "Регистрация"],
            ["POST", "/api/auth/challenge", "Получить challenge"],
            ["POST", "/api/auth/response", "Отправить ответ"],
            ["POST", "/api/auth/refresh", "Обновить access-token"],
            ["POST", "/api/auth/logout", "Выход"],
            ["GET", "/api/auth/users/me", "Текущий пользователь"],
        ],
    )
    add_para(doc, "Безопасность:", bold=True)
    add_bullets(doc, [
        "Пароль хранится только как bcrypt-хеш.",
        "Пароль не передаётся по сети - только HMAC-ответ на challenge.",
        "Токен в httpOnly cookie (недоступен JS).",
        "При 401 - редирект на форму входа.",
    ])

    # ---------- Шаг 2 ----------
    doc.add_page_break()
    add_heading(doc, "Шаг 2. RBAC - роли и разграничение доступа", level=1)
    add_para(doc, "Цель: разграничение доступа на основе ролей с проверкой строго на сервере.", bold=True)
    add_para(doc, "Роли:")
    add_table(doc,
        ["Роль", "Права"],
        [
            ["admin", "Полный доступ, управление пользователями, просмотр аудита"],
            ["manager", "Управление данными (создание/редактирование)"],
            ["user", "Базовый доступ (просмотр данных)"],
            ["guest", "Только просмотр публичных данных"],
        ],
    )
    add_para(doc, "Пример эндпоинтов:")
    add_table(doc,
        ["Метод", "Эндпоинт", "Мин. роль"],
        [
            ["GET", "/api/v1/public/info", "все"],
            ["GET", "/api/v1/user/profile", "user"],
            ["POST", "/api/v1/holders", "manager"],
            ["GET", "/api/v1/admin/users", "admin"],
            ["DELETE", "/api/v1/admin/users/{id}", "admin"],
            ["GET", "/api/v1/admin/logs", "admin"],
        ],
    )
    add_para(doc, "Скрытие кнопки в UI - только удобство. Прямой запрос к API всё равно отклоняется сервером (403).")

    # ---------- Шаг 3 ----------
    doc.add_page_break()
    add_heading(doc, "Шаг 3. Протоколирование и аудит", level=1)
    add_para(doc, "Цель: журнал событий ИБ в отдельной таблице БД с хеш-цепочкой.", bold=True)
    add_para(doc, "Логируемые события:")
    add_bullets(doc, [
        "Успешный и неуспешный вход (кто, когда, результат).",
        "Отказ в доступе по RBAC (403).",
        "Административные действия (создание/удаление пользователя, смена роли).",
        "Обращения к расшифровке защищённых полей.",
        "CSRF-отказы и срабатывания rate limit.",
    ])
    add_para(doc, "Структура записи:")
    add_table(doc,
        ["Поле", "Описание"],
        [
            ["id", "Первичный ключ"],
            ["timestamp", "Время события (UTC)"],
            ["user", "Пользователь или 'неизвестно'"],
            ["action", "Тип события"],
            ["outcome", "Успех/отказ"],
            ["details", "Детали"],
            ["ip_address", "IP-адрес"],
            ["prev_hash", "Хеш предыдущей записи"],
            ["hash", "Хеш текущей записи"],
        ],
    )
    add_para(doc, "Защита от утечки информации:", bold=True)
    add_para(doc,
        "Реакция на 'неверный пароль' и 'пользователь не существует' - внешне одинаковая. "
        "Это не даёт злоумышленнику понять, какие логины реальны."
    )
    add_para(doc, "API: GET /api/v1/admin/logs - только admin.")

    # ---------- Шаг 4 ----------
    doc.add_page_break()
    add_heading(doc, "Шаг 4. Криптография (Fernet + ГОСТ)", level=1)
    add_para(doc, "Цель: защита чувствительных полей БД шифрованием.", bold=True)
    add_para(doc, "Что шифруется:")
    add_bullets(doc, [
        "Email владельца пропуска.",
        "Телефон владельца пропуска.",
    ])
    add_para(doc, "Алгоритмы:")
    add_table(doc,
        ["Алгоритм", "Назначение", "Стандарт"],
        [
            ["Fernet (AES-128-CBC + HMAC-SHA256)", "Базовый", "-"],
            ["Кузнечик (CTR)", "Усиленный", "ГОСТ Р 34.12-2015"],
            ["Стрибог-256", "Хеш-функция", "ГОСТ Р 34.11-2012"],
            ["Магма", "Резерв", "ГОСТ 28147-89"],
        ],
    )
    add_para(doc, "Формат хранения:")
    add_bullets(doc, [
        "fernet:<base64> - зашифровано Fernet",
        "gost:<base64> - зашифровано Кузнечиком (CTR)",
    ])
    add_para(doc, "Проверка эталонных векторов:", bold=True)
    add_para(doc, "Кузнечик (ГОСТ Р 34.12-2015):", italic=True)
    add_para(doc, "  ключ: 8899aabbccddeeff0011223344556677fedcba98765432100123456789abcdef", italic=True)
    add_para(doc, "  вход: 1122334455667700ffeeddccbbaa9988", italic=True)
    add_para(doc, "  выход: 7f679d90bebc24305a468d42b9d4edcd", italic=True)
    add_para(doc, "Стрибог-256 (RFC 6986):", italic=True)
    add_para(doc, "  выход: 00557be5e584fd52a449b16b0251d05d27f94ab76cbaa6da890b59d8ef1e159d", italic=True)
    add_para(doc, "Ключи хранятся в .env / секретах, не в репозитории.")

    # ---------- Шаг 5 ----------
    doc.add_page_break()
    add_heading(doc, "Шаг 5. Подлинность исходящих документов", level=1)
    add_para(doc, "Цель: подпись экспортируемого документа приватным ключом приложения.", bold=True)
    add_para(doc, "Схема:")
    add_bullets(doc, [
        "Пользователь запрашивает экспорт (отчёт, выгрузка данных).",
        "Сервер формирует документ, вычисляет SHA-256 от содержимого.",
        "Сервер подписывает (ECDSA или RSA) хеш + метаданные (кем, когда).",
        "Документ отдаётся клиенту вместе с подписью и публичным ключом.",
        "Клиент (или внешняя система) может проверить подпись независимо.",
    ])
    add_para(doc, "API:")
    add_table(doc,
        ["Метод", "Эндпоинт", "Назначение"],
        [
            ["GET", "/api/v1/export/passes", "Экспорт пропусков с подписью"],
            ["POST", "/api/v1/verify/signature", "Проверка подписи"],
            ["GET", "/api/v1/signing/public-key", "Публичный ключ"],
        ],
    )
    add_para(doc, "Фронтенд:", bold=True)
    add_para(doc,
        "При просмотре/импорте документа явно отображается статус: "
        "'подпись верна' или 'документ изменён после подписи'."
    )
    add_para(doc, "Ключи:", bold=True)
    add_para(doc, "Приватный ключ - в keys/signing_key.pem, не в репозитории. Публичный - можно публиковать.")

    # ---------- Шаг 6 ----------
    doc.add_page_break()
    add_heading(doc, "Шаг 6. Управление сессиями и защита от веб-атак", level=1)
    add_para(doc, "Цель: закрыть типовые векторы атак поверх аутентификации и RBAC.", bold=True)
    add_para(doc, "Управление сессиями:")
    add_bullets(doc, [
        "Access-token (JWT) - 15 минут.",
        "Refresh-token - длительный, отзывается при logout и смене пароля.",
        "Список активных сессий пользователя (устройство, IP, время).",
        "Администратор может принудительно завершить все сессии пользователя.",
    ])
    add_para(doc, "CSRF-защита:")
    add_bullets(doc, [
        "Токен в httpOnly cookie + CSRF-токен в заголовке X-CSRF-Token.",
        "Double-submit cookie: сервер сверяет cookie и заголовок.",
        "Все изменяющие запросы (POST/PUT/DELETE) защищены.",
    ])
    add_para(doc, "XSS-защита:")
    add_bullets(doc, [
        "CSP: script-src 'self' - запрет inline-скриптов.",
        "Экранирование пользовательского ввода на фронтенде.",
        "Нет onclick/onchange в HTML - только addEventListener в app.js.",
    ])
    add_para(doc, "Защита от брутфорса:")
    add_bullets(doc, [
        "Rate limit на /api/auth/challenge и /api/auth/response.",
        "Экспоненциальная задержка после серии неудач.",
        "Логирование срабатываний rate limit.",
    ])
    add_para(doc, "Безопасные заголовки:")
    add_table(doc,
        ["Заголовок", "Значение"],
        [
            ["Content-Security-Policy", "default-src 'self'; script-src 'self'; frame-ancestors 'none'"],
            ["Strict-Transport-Security", "max-age=31536000; includeSubDomains"],
            ["X-Content-Type-Options", "nosniff"],
            ["X-Frame-Options", "DENY"],
            ["Referrer-Policy", "no-referrer"],
        ],
    )

    # ---------- Инфраструктура ----------
    doc.add_page_break()
    add_heading(doc, "Инфраструктура: Docker Compose", level=1)
    add_para(doc, "Docker Compose:", bold=True)
    add_bullets(doc, [
        "Сервис app - Flask-приложение на порту 8080.",
        "Volume ./data:/app/data - БД сохраняется между перезапусками.",
        "Volume ./keys:/app/keys:ro - ключи подписи только для чтения.",
        "Healthcheck - GET /api/v1/health каждые 30 секунд.",
    ])
    add_para(doc, "Запуск:")
    add_bullets(doc, [
        "docker compose up -d --build",
        "Открыть http://127.0.0.1:8080",
        "docker compose down - остановка",
    ])

    # ---------- Заключение ----------
    doc.add_page_break()
    add_heading(doc, "Заключение", level=1)
    add_para(doc, "Что реализовано:")
    add_bullets(doc, [
        "Шаг 0: переход Excel -> SQLite, генерация данных, разделение на backend/frontend/scripts.",
        "Шаг 1: challenge-response (вариант 7), bcrypt, JWT.",
        "Шаг 2: RBAC (4 роли), серверная проверка прав.",
        "Шаг 3: аудит с хеш-цепочкой, одинаковые ответы на ошибки входа.",
        "Шаг 4: Fernet + ГОСТ (Кузнечик, Стрибог), проверка эталонных векторов.",
        "Шаг 5: подпись экспорта RSA/ECDSA + SHA-256, проверка подписи.",
        "Шаг 6: сессии, CSRF, XSS, rate limit, безопасные заголовки.",
        "Инфраструктура: Docker Compose, установщик.",
    ])
    add_para(doc, "Остаточные риски:")
    add_bullets(doc, [
        "Challenge-response использует HMAC-SHA256 (не ГОСТ) из-за сложности JS-реализации Стрибога.",
        "SQLite подходит для одного инстанса; при масштабировании - PostgreSQL.",
        "Приватный ключ хранится в файле; для продакшена - HSM или KMS.",
    ])
    add_para(doc, "Что можно улучшить:")
    add_bullets(doc, [
        "Добавить 2FA (код на email) поверх challenge-response.",
        "Перейти на PostgreSQL для multi-instance.",
        "Интегрировать HSM для хранения ключей.",
        "Добавить внешний просмотрщик логов (ELK, Grafana Loki).",
    ])

    doc.save(OUTPUT)
    print(f"[+] Документ сохранён: {OUTPUT}")


if __name__ == "__main__":
    build_document()
