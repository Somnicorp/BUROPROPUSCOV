"""Репозиторий предметной области поверх SQLite.

Предоставляет CRUD-операции для holders, access_points, passes, access_logs.
Чувствительные поля владельца (email, phone) шифруются на этом уровне
(шаг 4): при записи - encrypt, при чтении - decrypt с записью в журнал
аудита о каждом обращении к расшифровке.
"""
from __future__ import annotations

from typing import Any

from . import crypto, database

# Колонки, доступные для чтения/записи по каждой сущности.
HOLDER_FIELDS = (
    "id", "full_name", "holder_type", "external_id",
    "department", "email", "phone", "created_at",
)
POINT_FIELDS = (
    "id", "name", "device_code", "location",
    "allow_entry", "allow_exit", "is_active", "created_at",
)
PASS_FIELDS = (
    "id", "card_number", "holder_id", "status", "zone",
    "valid_from", "valid_until", "comment", "created_at", "updated_at",
)
LOG_FIELDS = (
    "id", "pass_id", "card_number", "access_point_id",
    "direction", "result", "reason", "occurred_at",
)


def _row_to_dict(row, fields) -> dict:
    return {f: row[f] for f in fields} if row is not None else None


def _rows_to_dicts(rows, fields) -> list:
    return [{f: r[f] for f in fields} for r in rows]


# =====================================================================
#  Владельцы
# =====================================================================


def list_holders() -> list:
    with database.cursor() as cur:
        cur.execute("SELECT * FROM holders ORDER BY id")
        return [_row_to_dict(r, HOLDER_FIELDS) for r in cur.fetchall()]


def get_holder(holder_id: int) -> dict | None:
    with database.cursor() as cur:
        cur.execute("SELECT * FROM holders WHERE id = ?", (holder_id,))
        return _row_to_dict(cur.fetchone(), HOLDER_FIELDS)


def get_holder_by_external_id(external_id: str) -> dict | None:
    with database.cursor() as cur:
        cur.execute("SELECT * FROM holders WHERE external_id = ?", (external_id,))
        return _row_to_dict(cur.fetchone(), HOLDER_FIELDS)


def create_holder(data: dict) -> dict:
    now = database.utcnow()
    with database.cursor() as cur:
        cur.execute(
            "INSERT INTO holders (full_name, holder_type, external_id, department, "
            "email, phone, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                data.get("full_name"),
                data.get("holder_type", "employee"),
                data.get("external_id"),
                data.get("department"),
                crypto.encrypt_field(data.get("email")),
                crypto.encrypt_field(data.get("phone")),
                now,
            ),
        )
        new_id = cur.lastrowid
    return get_holder(new_id)


def update_holder(holder_id: int, updates: dict) -> dict | None:
    if not updates:
        return get_holder(holder_id)
    cols = []
    values = []
    for key, value in updates.items():
        if key not in HOLDER_FIELDS or key in ("id", "created_at"):
            continue
        if key in ("email", "phone"):
            value = crypto.encrypt_field(value)
        cols.append(f"{key} = ?")
        values.append(value)
    if not cols:
        return get_holder(holder_id)
    values.append(holder_id)
    with database.cursor() as cur:
        cur.execute(f"UPDATE holders SET {', '.join(cols)} WHERE id = ?", values)
    return get_holder(holder_id)


def delete_holder(holder_id: int) -> bool:
    with database.cursor() as cur:
        cur.execute("DELETE FROM holders WHERE id = ?", (holder_id,))
        return cur.rowcount > 0


# =====================================================================
#  Точки доступа
# =====================================================================


def list_access_points() -> list:
    with database.cursor() as cur:
        cur.execute("SELECT * FROM access_points ORDER BY id")
        return [_row_to_dict(r, POINT_FIELDS) for r in cur.fetchall()]


def get_access_point(point_id: int) -> dict | None:
    with database.cursor() as cur:
        cur.execute("SELECT * FROM access_points WHERE id = ?", (point_id,))
        return _row_to_dict(cur.fetchone(), POINT_FIELDS)


def get_access_point_by_code(code: str) -> dict | None:
    with database.cursor() as cur:
        cur.execute("SELECT * FROM access_points WHERE device_code = ?", (code,))
        return _row_to_dict(cur.fetchone(), POINT_FIELDS)


def create_access_point(data: dict) -> dict:
    now = database.utcnow()
    with database.cursor() as cur:
        cur.execute(
            "INSERT INTO access_points (name, device_code, location, allow_entry, "
            "allow_exit, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                data.get("name"),
                data.get("device_code"),
                data.get("location"),
                int(bool(data.get("allow_entry", True))),
                int(bool(data.get("allow_exit", True))),
                int(bool(data.get("is_active", True))),
                now,
            ),
        )
        new_id = cur.lastrowid
    return get_access_point(new_id)


def update_access_point(point_id: int, updates: dict) -> dict | None:
    if not updates:
        return get_access_point(point_id)
    cols = []
    values = []
    for key, value in updates.items():
        if key not in POINT_FIELDS or key in ("id", "created_at"):
            continue
        if key in ("allow_entry", "allow_exit", "is_active"):
            value = int(bool(value))
        cols.append(f"{key} = ?")
        values.append(value)
    if not cols:
        return get_access_point(point_id)
    values.append(point_id)
    with database.cursor() as cur:
        cur.execute(f"UPDATE access_points SET {', '.join(cols)} WHERE id = ?", values)
    return get_access_point(point_id)


def delete_access_point(point_id: int) -> bool:
    with database.cursor() as cur:
        cur.execute("DELETE FROM access_points WHERE id = ?", (point_id,))
        return cur.rowcount > 0


# =====================================================================
#  Пропуска
# =====================================================================


def list_passes(status: str = None, holder_id: int = None) -> list:
    query = "SELECT * FROM passes"
    clauses = []
    params = []
    if status:
        clauses.append("status = ?")
        params.append(status)
    if holder_id is not None:
        clauses.append("holder_id = ?")
        params.append(holder_id)
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    query += " ORDER BY id"
    with database.cursor() as cur:
        cur.execute(query, params)
        return [_row_to_dict(r, PASS_FIELDS) for r in cur.fetchall()]


def get_pass(pass_id: int) -> dict | None:
    with database.cursor() as cur:
        cur.execute("SELECT * FROM passes WHERE id = ?", (pass_id,))
        return _row_to_dict(cur.fetchone(), PASS_FIELDS)


def get_pass_by_card(card_number: str) -> dict | None:
    with database.cursor() as cur:
        cur.execute("SELECT * FROM passes WHERE card_number = ?", (card_number,))
        return _row_to_dict(cur.fetchone(), PASS_FIELDS)


def create_pass(data: dict) -> dict:
    now = database.utcnow()
    with database.cursor() as cur:
        cur.execute(
            "INSERT INTO passes (card_number, holder_id, status, zone, valid_from, "
            "valid_until, comment, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                data.get("card_number"),
                data.get("holder_id"),
                data.get("status", "active"),
                data.get("zone"),
                data.get("valid_from"),
                data.get("valid_until"),
                data.get("comment"),
                now,
                now,
            ),
        )
        new_id = cur.lastrowid
    return get_pass(new_id)


def update_pass(pass_id: int, updates: dict) -> dict | None:
    if not updates:
        return get_pass(pass_id)
    cols = []
    values = []
    for key, value in updates.items():
        if key not in PASS_FIELDS or key in ("id", "created_at"):
            continue
        cols.append(f"{key} = ?")
        values.append(value)
    cols.append("updated_at = ?")
    values.append(database.utcnow())
    values.append(pass_id)
    with database.cursor() as cur:
        cur.execute(f"UPDATE passes SET {', '.join(cols)} WHERE id = ?", values)
    return get_pass(pass_id)


def delete_pass(pass_id: int) -> bool:
    with database.cursor() as cur:
        cur.execute("DELETE FROM passes WHERE id = ?", (pass_id,))
        return cur.rowcount > 0


# =====================================================================
#  Журнал проходов
# =====================================================================


def append_access_log(entry: dict) -> dict:
    with database.cursor() as cur:
        cur.execute(
            "INSERT INTO access_logs (pass_id, card_number, access_point_id, "
            "direction, result, reason, occurred_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                entry.get("pass_id"),
                entry.get("card_number"),
                entry.get("access_point_id"),
                entry.get("direction"),
                entry.get("result"),
                entry.get("reason"),
                entry.get("occurred_at") or database.utcnow(),
            ),
        )
        new_id = cur.lastrowid
        cur.execute("SELECT * FROM access_logs WHERE id = ?", (new_id,))
        return _row_to_dict(cur.fetchone(), LOG_FIELDS)


def list_access_logs(limit: int = 200) -> list:
    with database.cursor() as cur:
        cur.execute(
            "SELECT * FROM access_logs ORDER BY occurred_at DESC, id DESC LIMIT ?",
            (int(limit),),
        )
        return [_row_to_dict(r, LOG_FIELDS) for r in cur.fetchall()]


# =====================================================================
#  Аналитика
# =====================================================================


def stats() -> dict:
    with database.cursor() as cur:
        total_passes = cur.execute("SELECT COUNT(*) FROM passes").fetchone()[0]
        total_holders = cur.execute("SELECT COUNT(*) FROM holders").fetchone()[0]
        total_points = cur.execute("SELECT COUNT(*) FROM access_points").fetchone()[0]
        total_logs = cur.execute("SELECT COUNT(*) FROM access_logs").fetchone()[0]
        by_status = {
            row[0]: row[1]
            for row in cur.execute(
                "SELECT status, COUNT(*) FROM passes GROUP BY status"
            ).fetchall()
        }
        granted = cur.execute(
            "SELECT COUNT(*) FROM access_logs WHERE result = 'granted'"
        ).fetchone()[0]
        denied = cur.execute(
            "SELECT COUNT(*) FROM access_logs WHERE result = 'denied'"
        ).fetchone()[0]
    return {
        "total_passes": total_passes,
        "total_holders": total_holders,
        "total_access_points": total_points,
        "total_logs": total_logs,
        "passes_by_status": by_status,
        "logs_granted": granted,
        "logs_denied": denied,
    }
