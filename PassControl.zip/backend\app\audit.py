"""Протоколирование и аудит событий безопасности (шаг 3).

Журнал хранится в отдельной таблице БД audit_logs и защищён хеш-цепочкой:
каждая запись содержит хеш предыдущей, поэтому незаметно удалить или
подменить старую запись нельзя - нарушится вся цепочка после неё.

Логируемые события (минимальный набор):
  * успешный/неуспешный вход;
  * отказ в доступе (RBAC, 403);
  * административные действия (создание/удаление пользователя, смена роли);
  * обращение к расшифровке защищённого поля (шаг 4);
  * срабатывание rate limit и CSRF (шаг 6).

Реакция на «неверный пароль» и «пользователь не существует» снаружи
одинакова (см. auth.login), поэтому журнал не даёт злоумышленнику
отличить реальное имя пользователя от несуществующего.
"""
from __future__ import annotations

import hashlib
import json

from . import database

# Категории событий.
ACTION_LOGIN_SUCCESS = "login_success"
ACTION_LOGIN_FAILURE = "login_failure"
ACTION_LOGOUT = "logout"
ACTION_REGISTER = "register"
ACTION_ACCESS_DENIED = "access_denied"
ACTION_ADMIN_USER_CREATE = "admin_user_create"
ACTION_ADMIN_USER_DELETE = "admin_user_delete"
ACTION_ADMIN_ROLE_CHANGE = "admin_role_change"
ACTION_ADMIN_SESSION_REVOKE = "admin_session_revoke"
ACTION_DECRYPT_FIELD = "decrypt_field"
ACTION_RATE_LIMIT = "rate_limit_triggered"
ACTION_CSRF_REJECT = "csrf_rejected"
ACTION_TOKEN_REFRESH = "token_refresh"
ACTION_SESSION_REVOKE = "session_revoke"
ACTION_EXPORT_SIGNED = "export_signed"


def _compute_hash(entry: dict, prev_hash: str) -> str:
    payload = json.dumps(
        {
            "occurred_at": entry["occurred_at"],
            "username": entry.get("username"),
            "user_id": entry.get("user_id"),
            "action": entry["action"],
            "outcome": entry["outcome"],
            "details": entry.get("details"),
            "ip_address": entry.get("ip_address"),
            "prev_hash": prev_hash,
        },
        ensure_ascii=False,
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def log_event(
    action: str,
    outcome: str = "success",
    username: str = None,
    user_id: int = None,
    details: str = None,
    ip_address: str = None,
) -> None:
    """Записывает событие в журнал аудита с хеш-цепочкой."""
    entry = {
        "occurred_at": database.utcnow(),
        "username": username,
        "user_id": user_id,
        "action": action,
        "outcome": outcome,
        "details": details,
        "ip_address": ip_address,
    }
    with database.cursor() as cur:
        prev = cur.execute(
            "SELECT entry_hash FROM audit_logs ORDER BY id DESC LIMIT 1"
        ).fetchone()
        prev_hash = prev[0] if prev else ""
        entry_hash = _compute_hash(entry, prev_hash)
        cur.execute(
            "INSERT INTO audit_logs (occurred_at, username, user_id, action, "
            "outcome, details, ip_address, prev_hash, entry_hash) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                entry["occurred_at"],
                entry["username"],
                entry["user_id"],
                entry["action"],
                entry["outcome"],
                entry["details"],
                entry["ip_address"],
                prev_hash,
                entry_hash,
            ),
        )


def list_logs(limit: int = 200) -> list:
    with database.cursor() as cur:
        cur.execute(
            "SELECT id, occurred_at, username, user_id, action, outcome, "
            "details, ip_address, entry_hash FROM audit_logs "
            "ORDER BY id DESC LIMIT ?",
            (int(limit),),
        )
        return [dict(r) for r in cur.fetchall()]


def verify_chain() -> dict:
    """Проверяет целостность всей хеш-цепочки журнала."""
    with database.cursor() as cur:
        rows = cur.execute(
            "SELECT occurred_at, username, user_id, action, outcome, details, "
            "ip_address, prev_hash, entry_hash FROM audit_logs ORDER BY id"
        ).fetchall()
    expected_prev = ""
    for index, row in enumerate(rows):
        entry = dict(row)
        stored_prev = entry.pop("prev_hash")
        stored_hash = entry.pop("entry_hash")
        if stored_prev != expected_prev:
            return {"valid": False, "broken_at": index, "reason": "prev_hash mismatch"}
        computed = _compute_hash(entry, stored_prev)
        if computed != stored_hash:
            return {"valid": False, "broken_at": index, "reason": "entry_hash mismatch"}
        expected_prev = stored_hash
    return {"valid": True, "entries": len(rows)}


# =====================================================================
#  Хук для crypto: логирование каждой расшифровки защищённого поля
# =====================================================================

# Контекст выполнения (кто расшифровывает) задаётся через Flask g.
_decrypt_context = {"username": None, "user_id": None, "ip": None}


def set_decrypt_context(username: str = None, user_id: int = None, ip: str = None) -> None:
    _decrypt_context["username"] = username
    _decrypt_context["user_id"] = user_id
    _decrypt_context["ip"] = ip


def _decrypt_hook(context: str, outcome: str) -> None:
    log_event(
        ACTION_DECRYPT_FIELD,
        outcome=outcome,
        username=_decrypt_context.get("username"),
        user_id=_decrypt_context.get("user_id"),
        details=f"field={context}",
        ip_address=_decrypt_context.get("ip"),
    )


def install_crypto_hook() -> None:
    """Связывает crypto с журналом аудита (вызывается при старте)."""
    from . import crypto
    crypto.set_audit_decrypt_hook(_decrypt_hook)
