﻿"""Генерация .env с секретами на основе .env.example.

Запуск из корня проекта:
    python scripts/generate_env.py
"""
from __future__ import annotations

import secrets
import sys
from pathlib import Path

from cryptography.fernet import Fernet


PROJECT_ROOT = Path(__file__).resolve().parent.parent
ENV_EXAMPLE = PROJECT_ROOT / ".env.example"
ENV_FILE = PROJECT_ROOT / ".env"


def main() -> int:
    if not ENV_EXAMPLE.exists():
        print(f"[ОШИБКА] {ENV_EXAMPLE} не найден.")
        return 1

    if ENV_FILE.exists():
        print(f"[!] {ENV_FILE} уже существует. Пропускаю.")
        return 0

    text = ENV_EXAMPLE.read_text(encoding="utf-8")

    # Генерируем секреты
    jwt = secrets.token_urlsafe(64)
    fernet = Fernet.generate_key().decode()
    gost = secrets.token_hex(32)

    # Подставляем
    text = text.replace("JWT_SECRET=change-me-to-a-long-random-string", f"JWT_SECRET={jwt}")
    text = text.replace("FERNET_KEY=change-me", f"FERNET_KEY={fernet}")
    text = text.replace("GOST_KEY=change-me", f"GOST_KEY={gost}")

    ENV_FILE.write_text(text, encoding="utf-8")

    # Права только владельцу (на Linux/macOS)
    try:
        import os
        os.chmod(ENV_FILE, 0o600)
    except OSError:
        pass

    print(f"[+] {ENV_FILE} создан с секретами.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
