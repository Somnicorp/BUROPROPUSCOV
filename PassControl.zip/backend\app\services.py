"""Бизнес-логика системы учёта и проверки пропусков (поверх SQLite).

Валидация, CRUD, проверка пропуска на КПП, журналирование проходов
и аналитика. Чувствительные поля владельцев расшифровываются при выдаче
(шаг 4); расшифровка фиксируется в журнале аудита.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from . import crypto, repository

PASS_STATUSES = ("active", "blocked", "expired", "revoked")
HOLDER_TYPES = ("employee", "student", "visitor", "contractor")
DIRECTIONS = ("entry", "exit")
RESULTS = ("granted", "denied")


class ValidationError(Exception):
    """Ошибка валидации входных данных."""


class NotFoundError(Exception):
    """Сущность не найдена."""


class ConflictError(Exception):
    """Конфликт (например, дубликат уникального поля)."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ─────────────────────────── Владельцы ───────────────────────────


def list_holders() -> list:
    return [crypto.decrypt_holder(h) for h in repository.list_holders()]


def get_holder(holder_id: int) -> dict:
    row = repository.get_holder(holder_id)
    if row is None:
        raise NotFoundError("Владелец не найден")
    return crypto.decrypt_holder(row)


def create_holder(data: dict) -> dict:
    full_name = (data.get("full_name") or "").strip()
    if not full_name:
        raise ValidationError("Поле full_name обязательно")
    holder_type = data.get("holder_type") or "employee"
    if holder_type not in HOLDER_TYPES:
        raise ValidationError(f"Недопустимый holder_type: {holder_type}")
    external_id = data.get("external_id")
    if external_id and repository.get_holder_by_external_id(external_id):
        raise ConflictError(f"external_id {external_id} уже используется")
    row = repository.create_holder({
        "full_name": full_name,
        "holder_type": holder_type,
        "external_id": external_id,
        "department": data.get("department"),
        "email": data.get("email"),
        "phone": data.get("phone"),
    })
    return crypto.decrypt_holder(row)


def update_holder(holder_id: int, data: dict) -> dict:
    get_holder(holder_id)
    if "holder_type" in data and data["holder_type"] not in HOLDER_TYPES:
        raise ValidationError(f"Недопустимый holder_type: {data['holder_type']}")
    allowed = {"full_name", "holder_type", "external_id", "department", "email", "phone"}
    updates = {k: v for k, v in data.items() if k in allowed}
    row = repository.update_holder(holder_id, updates)
    if row is None:
        raise NotFoundError("Владелец не найден")
    return crypto.decrypt_holder(row)


def delete_holder(holder_id: int) -> None:
    if not repository.delete_holder(holder_id):
        raise NotFoundError("Владелец не найден")


# ─────────────────────────── Точки доступа ───────────────────────────


def list_access_points() -> list:
    return repository.list_access_points()


def get_access_point(point_id: int) -> dict:
    row = repository.get_access_point(point_id)
    if row is None:
        raise NotFoundError("Точка доступа не найдена")
    return row


def _as_bool(value: Any, default: bool = True) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "да", "yes")


def create_access_point(data: dict) -> dict:
    name = (data.get("name") or "").strip()
    if not name:
        raise ValidationError("Поле name обязательно")
    device_code = data.get("device_code")
    if device_code and repository.get_access_point_by_code(device_code):
        raise ConflictError(f"device_code {device_code} уже используется")
    return repository.create_access_point({
        "name": name,
        "device_code": device_code,
        "location": data.get("location"),
        "allow_entry": _as_bool(data.get("allow_entry"), True),
        "allow_exit": _as_bool(data.get("allow_exit"), True),
        "is_active": _as_bool(data.get("is_active"), True),
    })


def update_access_point(point_id: int, data: dict) -> dict:
    get_access_point(point_id)
    allowed = {"name", "device_code", "location", "allow_entry", "allow_exit", "is_active"}
    updates = {k: v for k, v in data.items() if k in allowed}
    row = repository.update_access_point(point_id, updates)
    if row is None:
        raise NotFoundError("Точка доступа не найдена")
    return row


def delete_access_point(point_id: int) -> None:
    if not repository.delete_access_point(point_id):
        raise NotFoundError("Точка доступа не найдена")


# ─────────────────────────── Пропуска ───────────────────────────


def list_passes(status: str = None, holder_id: int = None) -> list:
    return repository.list_passes(status=status, holder_id=holder_id)


def get_pass(pass_id: int) -> dict:
    row = repository.get_pass(pass_id)
    if row is None:
        raise NotFoundError("Пропуск не найден")
    return row


def get_pass_by_card(card_number: str) -> dict | None:
    return repository.get_pass_by_card(card_number)


def create_pass(data: dict) -> dict:
    card_number = (data.get("card_number") or "").strip()
    if not card_number:
        raise ValidationError("Поле card_number обязательно")
    holder_id = data.get("holder_id")
    if holder_id is None:
        raise ValidationError("Поле holder_id обязательно")
    if repository.get_holder(int(holder_id)) is None:
        raise ValidationError("Владелец не найден")
    if repository.get_pass_by_card(card_number):
        raise ConflictError(f"Пропуск {card_number} уже существует")
    status = data.get("status") or "active"
    if status not in PASS_STATUSES:
        raise ValidationError(f"Недопустимый статус: {status}")
    return repository.create_pass({
        "card_number": card_number,
        "holder_id": int(holder_id),
        "status": status,
        "zone": data.get("zone"),
        "valid_from": data.get("valid_from") or _now(),
        "valid_until": data.get("valid_until"),
        "comment": data.get("comment"),
    })


def update_pass(pass_id: int, data: dict) -> dict:
    get_pass(pass_id)
    if "card_number" in data:
        existing = repository.get_pass_by_card(data["card_number"])
        if existing and int(existing["id"]) != int(pass_id):
            raise ConflictError(f"Пропуск {data['card_number']} уже существует")
    if "status" in data and data["status"] not in PASS_STATUSES:
        raise ValidationError(f"Недопустимый статус: {data['status']}")
    allowed = {"card_number", "holder_id", "status", "zone", "valid_from", "valid_until", "comment"}
    updates = {k: v for k, v in data.items() if k in allowed}
    row = repository.update_pass(pass_id, updates)
    if row is None:
        raise NotFoundError("Пропуск не найден")
    return row


def delete_pass(pass_id: int) -> None:
    if not repository.delete_pass(pass_id):
        raise NotFoundError("Пропуск не найден")


# ─────────────────────────── Проверка пропуска ───────────────────────────


def _parse_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        dt = value
    else:
        try:
            dt = datetime.fromisoformat(str(value))
        except (ValueError, TypeError):
            return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def verify_pass(card_number: str, access_point_id: int, direction: str = "entry") -> dict:
    """Проверяет пропуск на точке доступа и пишет запись в журнал проходов."""
    now = datetime.now(timezone.utc)
    if direction not in DIRECTIONS:
        raise ValidationError(f"Недопустимое направление: {direction}")
    point = get_access_point(int(access_point_id))

    pass_obj = get_pass_by_card(card_number)
    result = "denied"
    reason = "Пропуск не найден"
    pass_id = None
    holder_name = None

    if pass_obj is not None:
        pass_id = int(pass_obj["id"])
        try:
            holder_name = get_holder(int(pass_obj["holder_id"]))["full_name"]
        except (NotFoundError, KeyError, ValueError, TypeError):
            holder_name = None

        if pass_obj.get("status") != "active":
            reason = f"Пропуск не активен (статус: {pass_obj.get('status')})"
        else:
            valid_until = _parse_dt(pass_obj.get("valid_until"))
            if valid_until is not None and valid_until < now:
                reason = "Срок действия пропуска истёк"
            elif direction == "entry" and not _as_bool(point.get("allow_entry"), True):
                reason = "Вход на этой точке доступа запрещён"
            elif direction == "exit" and not _as_bool(point.get("allow_exit"), True):
                reason = "Выход на этой точке доступа запрещён"
            else:
                result = "granted"
                reason = "Доступ разрешён"

    repository.append_access_log({
        "pass_id": pass_id,
        "card_number": card_number,
        "access_point_id": int(access_point_id),
        "direction": direction,
        "result": result,
        "reason": reason,
        "occurred_at": now.isoformat(),
    })

    return {
        "result": result,
        "reason": reason,
        "pass_id": pass_id,
        "holder_name": holder_name,
        "checked_at": now.isoformat(),
    }


# ─────────────────────────── Журнал и аналитика ───────────────────────────


def list_logs(limit: int = 200) -> list:
    return repository.list_access_logs(limit=limit)


def stats() -> dict:
    return repository.stats()
