"""Установщик системы учёта и проверки пропусков.

Работает в двух режимах:
  1) Локальная установка из папки (offline):  python installer.py
     Файлы копируются из текущей папки в целевую директорию.
  2) Загрузка файлов по сети (online):        python installer.py --url <BASE_URL>
     Файлы скачиваются с сервера (например, GitHub Releases или файловый сервер),
     затем разворачиваются и подготавливается окружение.

После установки создаётся ярлык запуска start.bat / start.sh.
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import urllib.error
import urllib.request

DEFAULT_INSTALL_DIR = os.path.join(os.path.expanduser("~"), "FlaskPassControl")

# Список файлов проекта, которые нужно загрузить/скопировать.
PROJECT_FILES = [
    "run.py",
    "generate_data.py",
    "requirements.txt",
    "start.bat",
    "start.sh",
    "README.md",
    "app/__init__.py",
    "app/api.py",
    "app/api_deps.py",
    "app/auth.py",
    "app/audit.py",
    "app/config.py",
    "app/crypto.py",
    "app/database.py",
    "app/gost.py",
    "app/main.py",
    "app/middleware.py",
    "app/repository.py",
    "app/security.py",
    "app/services.py",
    "app/users.py",
    "app/templates/index.html",
    "app/static/app.js",
    "app/static/style.css",
]


def log(msg: str) -> None:
    print(f"  {msg}")


def download_file(url: str, dest: str, timeout: int = 60) -> None:
    """Скачивает один файл по URL в dest, создавая каталоги."""
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "PassControlInstaller/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read()
    with open(dest, "wb") as fh:
        fh.write(data)


def install_offline(source_dir: str, target_dir: str) -> None:
    """Копирует файлы проекта из source_dir в target_dir."""
    for rel in PROJECT_FILES:
        src = os.path.join(source_dir, rel)
        dst = os.path.join(target_dir, rel)
        if not os.path.exists(src):
            log(f"[пропуск] нет файла: {rel}")
            continue
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
        log(f"скопирован: {rel}")


def install_online(base_url: str, target_dir: str) -> None:
    """Скачивает файлы проекта с сервера."""
    base = base_url.rstrip("/")
    for rel in PROJECT_FILES:
        url = f"{base}/{rel}"
        dst = os.path.join(target_dir, rel)
        try:
            download_file(url, dst)
            log(f"скачан: {rel}")
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as exc:
            log(f"[ошибка] {rel}: {exc}")


def setup_environment(target_dir: str, skip_deps: bool = False) -> None:
    """Создаёт venv, ставит зависимости и генерирует БД."""
    python = sys.executable
    venv_dir = os.path.join(target_dir, ".venv")
    if not os.path.exists(venv_dir):
        log("создание виртуального окружения...")
        subprocess.run([python, "-m", "venv", venv_dir], check=True)

    if os.name == "nt":
        venv_python = os.path.join(venv_dir, "Scripts", "python.exe")
    else:
        venv_python = os.path.join(venv_dir, "bin", "python")

    if not skip_deps:
        log("установка зависимостей...")
        subprocess.run([venv_python, "-m", "pip", "install", "--upgrade", "pip"],
                       cwd=target_dir, check=False)
        subprocess.run([venv_python, "-m", "pip", "install", "-r", "requirements.txt"],
                       cwd=target_dir, check=True)

    db_path = os.path.join(target_dir, "data", "pass_control.sqlite3")
    if not os.path.exists(db_path):
        log("генерация базы данных SQLite...")
        try:
            subprocess.run([venv_python, "generate_data.py"], cwd=target_dir, check=True)
        except subprocess.CalledProcessError as exc:
            log(f"[предупреждение] не удалось сгенерировать БД: {exc}")
            log("БД будет создана автоматически при первом запуске приложения.")


def create_launcher(target_dir: str) -> None:
    """Создаёт ярлык/скрипт запуска."""
    if os.name == "nt":
        launcher = os.path.join(target_dir, "Запустить.bat")
        with open(launcher, "w", encoding="utf-8") as fh:
            fh.write("@echo off\nchcp 65001 >nul\ncd /d \"%~dp0\"\ncall .venv\\Scripts\\activate.bat\npython run.py\npause\n")
        log(f"создан ярлык: {launcher}")
    else:
        launcher = os.path.join(target_dir, "запустить.sh")
        with open(launcher, "w", encoding="utf-8") as fh:
            fh.write("#!/usr/bin/env bash\ncd \"$(dirname \"$0\")\"\nsource .venv/bin/activate\npython run.py\n")
        os.chmod(launcher, 0o755)
        log(f"создан ярлык: {launcher}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Установщик системы учёта и проверки пропусков")
    parser.add_argument("--dir", default=DEFAULT_INSTALL_DIR, help="куда устанавливать")
    parser.add_argument("--url", default=None, help="базовый URL для онлайн-загрузки файлов")
    parser.add_argument("--source", default=os.path.dirname(os.path.abspath(__file__)),
                        help="папка-источник для офлайн-установки")
    parser.add_argument("--skip-deps", action="store_true", help="не устанавливать зависимости")
    args = parser.parse_args()

    target = os.path.abspath(args.dir)
    print("============================================================")
    print("  Установка: Система учёта и проверки пропусков")
    print("============================================================")
    print(f"  Каталог установки: {target}")
    os.makedirs(target, exist_ok=True)

    if args.url:
        print("  Режим: онлайн-загрузка")
        install_online(args.url, target)
    else:
        print("  Режим: локальная установка")
        install_offline(args.source, target)

    try:
        setup_environment(target, skip_deps=args.skip_deps)
        create_launcher(target)
    except subprocess.CalledProcessError as exc:
        print(f"[ОШИБКА] Не удалось подготовить окружение: {exc}")
        return 1

    print("\nГотово!")
    print(f"Запустите: {os.path.join(target, 'Запустить.bat' if os.name == 'nt' else 'запустить.sh')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
