﻿"""Конфигурация приложения и секреты."""
from __future__ import annotations

import os
from pathlib import Path


# Корень проекта = на уровень выше backend/
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent

# Папки
DATA_DIR = PROJECT_ROOT / "data"
KEYS_DIR = PROJECT_ROOT / "keys"
DOCS_DIR = PROJECT_ROOT / "docs"

DATA_DIR.mkdir(exist_ok=True)
KEYS_DIR.mkdir(exist_ok=True)


def _load_dotenv() -> None:
    """Простой загрузчик .env без внешних зависимостей."""
    env_path = PROJECT_ROOT / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


_load_dotenv()


# ---------- JWT ----------
JWT_SECRET = os.environ.get("JWT_SECRET", "dev-secret-change-me")
JWT_ACCESS_TTL = int(os.environ.get("JWT_ACCESS_TTL", "900"))
JWT_REFRESH_TTL = int(os.environ.get("JWT_REFRESH_TTL", "1209600"))

# ---------- Крипто (шаг 4) ----------
FERNET_KEY = os.environ.get("FERNET_KEY", "")
GOST_KEY = os.environ.get("GOST_KEY", "")
CRYPTO_BACKEND = os.environ.get("CRYPTO_BACKEND", "fernet")

# ---------- Подпись (шаг 5) ----------
SIGNING_PRIVATE_KEY_PATH = PROJECT_ROOT / os.environ.get(
    "SIGNING_PRIVATE_KEY_PATH", "keys/signing_key.pem")
SIGNING_PUBLIC_KEY_PATH = PROJECT_ROOT / os.environ.get(
    "SIGNING_PUBLIC_KEY_PATH", "keys/signing_public.pem")
SIGNING_ALGORITHM = os.environ.get("SIGNING_ALGORITHM", "ecdsa")

# ---------- БД ----------
DB_PATH = PROJECT_ROOT / os.environ.get(
    "PASS_DB_PATH", "data/pass_control.sqlite3")

# ---------- Сервер ----------
HOST = os.environ.get("PASS_HOST", "127.0.0.1")
PORT = int(os.environ.get("PASS_PORT", "8080"))
DEBUG = os.environ.get("PASS_DEBUG", "0") == "1"

# ---------- Безопасность (шаг 6) ----------
AUTH_RATE_LIMIT = int(os.environ.get("AUTH_RATE_LIMIT", "10"))
CHALLENGE_TTL = int(os.environ.get("CHALLENGE_TTL", "120"))
AUDIT_CHAIN_LIMIT = int(os.environ.get("AUDIT_CHAIN_LIMIT", "1000"))


# =====================================================================
#  Функции-геттеры (для совместимости с crypto.py, security.py и др.)
# =====================================================================

def gost_key() -> bytes:
    """Ключ Кузнечика (32 байта). Из .env GOST_KEY (hex) или дефолт."""
    raw = GOST_KEY or "00" * 32
    try:
        return bytes.fromhex(raw)
    except ValueError:
        return raw.encode("utf-8")[:32].ljust(32, b"\0")


def fernet_key() -> bytes:
    """Ключ Fernet (base64). Из .env FERNET_KEY или сгенерированный."""
    if FERNET_KEY:
        return FERNET_KEY.encode("utf-8")
    import base64
    return base64.urlsafe_b64encode(b"0" * 32)


def jwt_secret() -> str:
    return JWT_SECRET


def crypto_backend() -> str:
    return CRYPTO_BACKEND


def signing_private_key_path() -> Path:
    return SIGNING_PRIVATE_KEY_PATH


def signing_public_key_path() -> Path:
    return SIGNING_PUBLIC_KEY_PATH


def signing_algorithm() -> str:
    return SIGNING_ALGORITHM


def db_path() -> Path:
    return DB_PATH


# =====================================================================
#  Алиасы (для совместимости с auth.py / security.py)
# =====================================================================

ACCESS_TOKEN_TTL = JWT_ACCESS_TTL
REFRESH_TOKEN_TTL = JWT_REFRESH_TTL


# =====================================================================
#  Дополнительные алиасы (по результатам check_all_cfg)
# =====================================================================

# Разрешить работу без HTTPS (для разработки на localhost)
ALLOW_INSECURE = os.environ.get("ALLOW_INSECURE", "1") == "1"

# Rate limit на вход (алиасы + явные значения)
LOGIN_RATE_LIMIT = int(os.environ.get("LOGIN_RATE_LIMIT", "10"))
LOGIN_RATE_WINDOW = int(os.environ.get("LOGIN_RATE_WINDOW", "60"))


def signing_private_key_pem() -> str:
    """Приватный ключ подписи в PEM (строка). Нужен для crypto.py."""
    if not SIGNING_PRIVATE_KEY_PATH.exists():
        raise FileNotFoundError(
            f"Приватный ключ не найден: {SIGNING_PRIVATE_KEY_PATH}"
        )
    return SIGNING_PRIVATE_KEY_PATH.read_text(encoding="utf-8")


def signing_public_key_pem() -> str:
    """Публичный ключ подписи в PEM (строка)."""
    if not SIGNING_PUBLIC_KEY_PATH.exists():
        # Попробуем сгенерировать из приватного
        from cryptography.hazmat.primitives import serialization
        if SIGNING_PRIVATE_KEY_PATH.exists():
            data = SIGNING_PRIVATE_KEY_PATH.read_bytes()
            priv = serialization.load_pem_private_key(data, password=None)
            pem = priv.public_key().public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo,
            ).decode("ascii")
            SIGNING_PUBLIC_KEY_PATH.write_text(pem, encoding="utf-8")
            return pem
        raise FileNotFoundError(
            f"Публичный ключ не найден: {SIGNING_PUBLIC_KEY_PATH}"
        )
    return SIGNING_PUBLIC_KEY_PATH.read_text(encoding="utf-8")
