"""Безопасность: пароли, JWT, сессии, rate limit, CSRF (шаги 1, 2, 6).

Пароли:
  * всегда хранятся хешированными (bcrypt);
  * никогда не логируются и не выводятся в открытом виде.

Токены:
  * короткоживущий access-token (JWT, 15 минут);
  * refresh-token (opaque, хранится хешированным в таблице sessions);
  * хранятся в httpOnly cookie (предпочтительный вариант по ТЗ).

Сессии:
  * список активных сессий, отзыв по одной, отзыв всех сессий пользователя.

Защита от атак:
  * rate limiting на /login и /challenge;
  * CSRF double-submit cookie для изменяющих запросов;
  * безопасные заголовки HTTP (CSP, HSTS, X-Frame-Options и др.).
"""
from __future__ import annotations

import hashlib
import hmac
import secrets
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

import bcrypt
import jwt

from . import audit, config, database

# ─────────────── Пароли ───────────────

BCRYPT_ROUNDS = 12


def hash_password(password: str) -> str:
    """bcrypt-хеш пароля."""
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(rounds=BCRYPT_ROUNDS)).decode("ascii")


def verify_password(password: str, password_hash: str) -> bool:
    """Проверка пароля по bcrypt-хешу. Не логирует пароль."""
    try:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("ascii"))
    except (ValueError, TypeError):
        return False


def password_strength_ok(password: str) -> tuple:
    """Минимальные требования к сложности пароля (шаг 1)."""
    if password is None or len(password) < 8:
        return False, "Пароль должен содержать не менее 8 символов"
    if not any(c.isdigit() for c in password):
        return False, "Пароль должен содержать хотя бы одну цифру"
    if not any(c.isalpha() for c in password):
        return False, "Пароль должен содержать хотя бы одну букву"
    return True, ""


# ─────────────── JWT ───────────────

JWT_ALG = "HS256"


def _jwt_secret() -> str:
    return config.jwt_secret()


def create_access_token(user: dict, session_id: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user["id"]),
        "username": user["username"],
        "role": user["role"],
        "sid": session_id,
        "type": "access",
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(seconds=config.ACCESS_TOKEN_TTL)).timestamp()),
    }
    return jwt.encode(payload, _jwt_secret(), algorithm=JWT_ALG)


def decode_access_token(token: str) -> dict | None:
    try:
        payload = jwt.decode(token, _jwt_secret(), algorithms=[JWT_ALG])
    except jwt.PyJWTError:
        return None
    if payload.get("type") != "access":
        return None
    return payload


# ─────────────── Refresh-токены и сессии ───────────────


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def create_session(user_id: int, user_agent: str = None, ip: str = None) -> dict:
    """Создаёт сессию и возвращает refresh-token (opaque)."""
    session_id = str(uuid.uuid4())
    refresh_token = secrets.token_urlsafe(48)
    now = datetime.now(timezone.utc)
    expires = now + timedelta(seconds=config.REFRESH_TOKEN_TTL)
    with database.cursor() as cur:
        cur.execute(
            "INSERT INTO sessions (id, user_id, refresh_hash, user_agent, "
            "ip_address, created_at, last_seen_at, expires_at, revoked) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)",
            (
                session_id,
                user_id,
                _hash_token(refresh_token),
                (user_agent or "")[:255],
                ip,
                now.isoformat(),
                now.isoformat(),
                expires.isoformat(),
            ),
        )
    return {"session_id": session_id, "refresh_token": refresh_token}


def validate_refresh(session_id: str, refresh_token: str) -> dict | None:
    with database.cursor() as cur:
        row = cur.execute(
            "SELECT * FROM sessions WHERE id = ?", (session_id,)
        ).fetchone()
    if row is None:
        return None
    session = dict(row)
    if session["revoked"]:
        return None
    if session["refresh_hash"] != _hash_token(refresh_token):
        return None
    try:
        expires = datetime.fromisoformat(session["expires_at"])
    except (ValueError, TypeError):
        return None
    if expires < datetime.now(timezone.utc):
        return None
    with database.cursor() as cur:
        cur.execute(
            "UPDATE sessions SET last_seen_at = ? WHERE id = ?",
            (database.utcnow(), session_id),
        )
    return session


def revoke_session(session_id: str) -> bool:
    with database.cursor() as cur:
        cur.execute("UPDATE sessions SET revoked = 1 WHERE id = ?", (session_id,))
        return cur.rowcount > 0


def revoke_all_user_sessions(user_id: int) -> int:
    with database.cursor() as cur:
        cur.execute(
            "UPDATE sessions SET revoked = 1 WHERE user_id = ? AND revoked = 0",
            (user_id,),
        )
        return cur.rowcount


def list_user_sessions(user_id: int) -> list:
    with database.cursor() as cur:
        cur.execute(
            "SELECT id, user_agent, ip_address, created_at, last_seen_at, "
            "expires_at, revoked FROM sessions WHERE user_id = ? "
            "ORDER BY last_seen_at DESC",
            (user_id,),
        )
        return [dict(r) for r in cur.fetchall()]


def is_session_active(session_id: str) -> bool:
    with database.cursor() as cur:
        row = cur.execute(
            "SELECT revoked FROM sessions WHERE id = ?", (session_id,)
        ).fetchone()
    return bool(row) and not row[0]


# ─────────────── Rate limiting ───────────────

_rate_buckets: dict = {}
_rate_lock = __import__("threading").Lock()


def rate_limit_check(key: str) -> bool:
    """True - запрос разрешён, False - превышен лимит."""
    now = time.monotonic()
    window = config.LOGIN_RATE_WINDOW
    limit = config.LOGIN_RATE_LIMIT
    with _rate_lock:
        bucket = _rate_buckets.setdefault(key, [])
        bucket[:] = [t for t in bucket if now - t < window]
        if len(bucket) >= limit:
            return False
        bucket.append(now)
        return True


def rate_limit_reset(key: str) -> None:
    with _rate_lock:
        _rate_buckets.pop(key, None)


# ─────────────── CSRF (double-submit cookie) ───────────────

CSRF_COOKIE = "csrf_token"
CSRF_HEADER = "X-CSRF-Token"


def generate_csrf_token() -> str:
    return secrets.token_urlsafe(32)


def csrf_valid(cookie_token: str, header_token: str) -> bool:
    if not cookie_token or not header_token:
        return False
    return hmac.compare_digest(cookie_token, header_token)
