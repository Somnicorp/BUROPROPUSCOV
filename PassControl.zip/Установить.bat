@echo off
chcp 65001 >nul
title Установка и запуск — Система учёта пропусков
cd /d "%~dp0"

echo ============================================================
echo   Система учёта и проверки пропусков
echo   Установка и запуск (Windows)
echo ============================================================
echo.

REM --- 1. Проверка Python ---
where python >nul 2>nul
if errorlevel 1 (
    echo [ОШИБКА] Python не найден в PATH.
    echo Установите Python 3.10+ с https://www.python.org/downloads/
    echo При установке отметьте "Add Python to PATH".
    pause
    exit /b 1
)
echo [*] Python найден.
echo.

REM --- 2. Виртуальное окружение ---
if not exist ".venv\Scripts\python.exe" (
    echo [*] Создание виртуального окружения...
    python -m venv .venv
    if errorlevel 1 (
        echo [ОШИБКА] Не удалось создать venv.
        pause
        exit /b 1
    )
) else (
    echo [*] Виртуальное окружение уже существует.
)

REM --- 3. Зависимости ---
echo [*] Установка зависимостей...
".venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
".venv\Scripts\python.exe" -m pip install -r backend\requirements.txt --quiet
if errorlevel 1 (
    echo [ОШИБКА] Не удалось установить зависимости.
    pause
    exit /b 1
)
echo [*] Зависимости установлены.
echo.

REM --- 4. .env ---
if not exist ".env" (
    echo [*] Генерация .env с секретами...
    if not exist ".env.example" (
        echo [ОШИБКА] .env.example не найден.
        pause
        exit /b 1
    )
    copy /Y ".env.example" ".env" >nul
    ".venv\Scripts\python.exe" scripts\generate_env.py
    if errorlevel 1 (
        echo [ОШИБКА] Не удалось сгенерировать .env.
        pause
        exit /b 1
    )
    echo [*] .env создан.
) else (
    echo [*] .env уже существует.
)
echo.

REM --- 5. База данных ---
if not exist "data\pass_control.sqlite3" (
    echo [*] Генерация базы данных...
    ".venv\Scripts\python.exe" scripts\generate_data.py
    if errorlevel 1 (
        echo [ОШИБКА] Не удалось сгенерировать БД.
        pause
        exit /b 1
    )
) else (
    echo [*] База данных уже существует.
)

REM --- 5.1. Файл тестовых учёток ---
if not exist "ТЕСТОВЫЕ_УЧЁТКИ.txt" (
    if exist "ТЕСТОВЫЕ_УЧЁТКИ.txt.example" (
        copy /Y "ТЕСТОВЫЕ_УЧЁТКИ.txt.example" "ТЕСТОВЫЕ_УЧЁТКИ.txt" >nul
        echo [*] Создан ТЕСТОВЫЕ_УЧЁТКИ.txt из шаблона.
    )
)

REM --- 6. Ключи подписи ---
if not exist "keys\signing_key.pem" (
    echo [*] Генерация ключей подписи...
    ".venv\Scripts\python.exe" scripts\generate_keys.py
    if errorlevel 1 (
        echo [ОШИБКА] Не удалось сгенерировать ключи.
        pause
        exit /b 1
    )
) else (
    echo [*] Ключи подписи уже существуют.
)
echo.

REM --- 7. Запуск сервера в отдельном окне ---
echo [*] Запуск сервера...
start "Pass Control Server" cmd /k ".venv\Scripts\python.exe backend\run.py"

REM --- 8. Ожидание готовности ---
echo [*] Ожидание запуска сервера (6 сек)...
timeout /t 6 /nobreak >nul

REM --- 9. Открытие браузера ---
echo [*] Открытие браузера...
start http://127.0.0.1:8080

echo.
echo ============================================================
echo   ГОТОВО
echo ============================================================
echo   Адрес:  http://127.0.0.1:8080
echo.
echo   Тестовые пользователи:
echo     admin    / 123456789     (полный доступ)
echo     manager  / 123456789     (управление данными)
echo     user     / 123456789     (базовый доступ)
echo     guest    / 123456789     (только просмотр)
echo.
echo   Для остановки сервера закройте окно "Pass Control Server".
echo ============================================================
echo.
pause