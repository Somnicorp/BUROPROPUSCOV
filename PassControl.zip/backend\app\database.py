"""Слой базы данных SQLite (замена Excel-хранилища).

Все данные приложения (предметная область, пользователи, сессии, журнал
аудита) хранятся в одном файле SQLite. Это даёт:
  * транзакционную целостность (ACID) вместо атомарной перезаписи .xlsx;
  * конкурентный доступ из нескольких потоков без гонок;
  * индексы и SQL-фильтрацию вместо чтения всего файла в память;
  * единое место для таблиц безопасности (users, sessions, audit_logs).

Соединение создаётся на поток (thread-local), т.к. SQLite по умолчанию
не допускает использование одного соединения из разных потоков.
"""
from __future__ import annotations

import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path

from . import config

_LOCAL = threading.local()
_INIT_LOCK = threading.Lock()


# =====================================================================
#  Схема базы данных
# =====================================================================

SCHEMA = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- ─────────────── Предметная область (шаг 0) ───────────────

CREATE TABLE IF NOT EXISTS holders (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name     TEXT NOT NULL,
    holder_type   TEXT NOT NULL DEFAULT 'employee',
    external_id   TEXT UNIQUE,
    department    TEXT,
    email         TEXT,          -- шифруется (шаг 4)
    phone         TEXT,          -- шифруется (шаг 4)
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS access_points (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    device_code   TEXT UNIQUE,
    location      TEXT,
    allow_entry   INTEGER NOT NULL DEFAULT 1,
    allow_exit    INTEGER NOT NULL DEFAULT 1,
    is_active     INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS passes (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    card_number   TEXT NOT NULL UNIQUE,
    holder_id     INTEGER NOT NULL REFERENCES holders(id) ON DELETE CASCADE,
    status        TEXT NOT NULL DEFAULT 'active',
    zone          TEXT,
    valid_from    TEXT,
    valid_until   TEXT,
    comment       TEXT,
    created_at    TEXT NOT NULL,
    updated_at    TEXT
);

CREATE TABLE IF NOT EXISTS access_logs (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    pass_id          INTEGER REFERENCES passes(id) ON DELETE SET NULL,
    card_number      TEXT,
    access_point_id  INTEGER REFERENCES access_points(id) ON DELETE SET NULL,
    direction        TEXT NOT NULL,
    result           TEXT NOT NULL,
    reason           TEXT,
    occurred_at      TEXT NOT NULL
);

-- ─────────────── Аутентификация и RBAC (шаги 1-2) ───────────────

CREATE TABLE IF NOT EXISTS users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    username        TEXT NOT NULL UNIQUE,
    password_hash   TEXT NOT NULL,        -- bcrypt, никогда не логируется
    challenge_key   TEXT,                 -- HMAC-ключ для «рукопожатия»
    role            TEXT NOT NULL DEFAULT 'user',
    challenge       TEXT,                 -- для метода «рукопожатие»
    challenge_until TEXT,
    is_active       INTEGER NOT NULL DEFAULT 1,
    password_changed_at TEXT,
    created_at      TEXT NOT NULL,
    last_login_at   TEXT
);

-- ─────────────── Сессии (шаг 6) ───────────────

CREATE TABLE IF NOT EXISTS sessions (
    id             TEXT PRIMARY KEY,       -- идентификатор сессии (jti)
    user_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    refresh_hash   TEXT NOT NULL,          -- хеш refresh-токена
    user_agent     TEXT,
    ip_address     TEXT,
    created_at     TEXT NOT NULL,
    last_seen_at   TEXT NOT NULL,
    expires_at     TEXT NOT NULL,
    revoked        INTEGER NOT NULL DEFAULT 0
);

-- ─────────────── Журнал аудита (шаг 3) ───────────────

CREATE TABLE IF NOT EXISTS audit_logs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    occurred_at  TEXT NOT NULL,
    username     TEXT,
    user_id      INTEGER,
    action       TEXT NOT NULL,
    outcome      TEXT NOT NULL,            -- success / failure
    details      TEXT,
    ip_address   TEXT,
    prev_hash    TEXT,                     -- хеш-цепочка для целостности
    entry_hash   TEXT NOT NULL
);

-- ─────────────── Одноразовые пароли (метод OTP, вариант 6) ───────────────

CREATE TABLE IF NOT EXISTS otp_codes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    code_hash   TEXT NOT NULL,
    used        INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL,
    expires_at  TEXT NOT NULL
);

-- ─────────────── Индексы ───────────────

CREATE INDEX IF NOT EXISTS idx_passes_holder   ON passes(holder_id);
CREATE INDEX IF NOT EXISTS idx_passes_status    ON passes(status);
CREATE INDEX IF NOT EXISTS idx_logs_occurred    ON access_logs(occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_logs_pass        ON access_logs(pass_id);
CREATE INDEX IF NOT EXISTS idx_sessions_user    ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_occurred   ON audit_logs(occurred_at DESC);
"""


# =====================================================================
#  Соединение
# =====================================================================


def get_connection() -> sqlite3.Connection:
    """Возвращает соединение SQLite, привязанное к текущему потоку."""
    conn = getattr(_LOCAL, "conn", None)
    if conn is None:
        config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(config.DB_PATH), timeout=30, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        _LOCAL.conn = conn
    return conn


class _Cursor:
    """Контекстный менеджер для удобной работы с курсором."""

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.cur = conn.cursor()

    def __enter__(self):
        return self.cur

    def __exit__(self, exc_type, exc, tb):
        try:
            self.cur.close()
        except sqlite3.Error:
            pass
        if exc_type is None:
            self.conn.commit()
        else:
            self.conn.rollback()


def cursor():
    return _Cursor(get_connection())


# =====================================================================
#  Инициализация
# =====================================================================


def init_db(force: bool = False) -> None:
    """Создаёт схему БД. force=True удаляет существующий файл."""
    with _INIT_LOCK:
        if force and config.DB_PATH.exists():
            # Закрываем текущее соединение потока, чтобы файл освободился.
            conn = getattr(_LOCAL, "conn", None)
            if conn is not None:
                try:
                    conn.close()
                except sqlite3.Error:
                    pass
                _LOCAL.conn = None
            config.DB_PATH.unlink(missing_ok=True)
            for suffix in ("-wal", "-shm"):
                Path(str(config.DB_PATH) + suffix).unlink(missing_ok=True)
        conn = get_connection()
        conn.executescript(SCHEMA)
        conn.commit()


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()
