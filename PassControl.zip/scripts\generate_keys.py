﻿"""Генерация ключей подписи документов (шаг 5)."""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa


PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

KEYS_DIR = PROJECT_ROOT / "keys"
PRIVATE_PATH = KEYS_DIR / "signing_key.pem"
PUBLIC_PATH = KEYS_DIR / "signing_public.pem"


def generate_ecdsa():
    return ec.generate_private_key(ec.SECP256R1())


def generate_rsa(bits: int = 2048):
    return rsa.generate_private_key(public_exponent=65537, key_size=bits)


def save_keys(private_key, private_path: Path, public_path: Path) -> None:
    private_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    private_path.write_bytes(private_bytes)
    try:
        os.chmod(private_path, 0o600)
    except OSError:
        pass

    public_bytes = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    public_path.write_bytes(public_bytes)


def main() -> int:
    parser = argparse.ArgumentParser(description="Генерация ключей подписи")
    parser.add_argument("--algo", choices=["ecdsa", "rsa"], default="ecdsa")
    parser.add_argument("--rsa-bits", type=int, default=2048)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    KEYS_DIR.mkdir(exist_ok=True)

    if PRIVATE_PATH.exists() and not args.force:
        print(f"[!] Приватный ключ уже существует: {PRIVATE_PATH}")
        print("    Используйте --force для перезаписи.")
        return 1

    if args.algo == "ecdsa":
        print("[*] Генерация ECDSA (secp256r1)...")
        private_key = generate_ecdsa()
    else:
        print(f"[*] Генерация RSA-{args.rsa_bits}...")
        private_key = generate_rsa(args.rsa_bits)

    save_keys(private_key, PRIVATE_PATH, PUBLIC_PATH)

    print(f"[+] Приватный ключ: {PRIVATE_PATH}")
    print(f"[+] Публичный ключ: {PUBLIC_PATH}")
    print()
    print("[!] Приватный ключ НЕ коммитится (см. .gitignore).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
